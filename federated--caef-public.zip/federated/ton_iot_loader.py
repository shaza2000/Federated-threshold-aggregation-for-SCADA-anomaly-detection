"""
ton_iot_loader.py
=================
Loads TON_IoT-style IoT-device telemetry CSV files (Alsaedi et al., 2020 [1])
and maps each row to a CAEF MQTT event whose attribute layout mirrors the
paper's Equation 1 (Section 3.3.1).

DATA NOTE (TODO for the authors before publication)
---------------------------------------------------
The loader expects a UNIFIED schema (timestamp, device_id, device_type,
temperature, humidity, pressure, voltage, current, power, status, label),
which is NOT the schema of the original public TON_IoT per-device files
(those use columns such as fridge_temperature, temp_condition, type, ...).
TODO(authors): state here and in the README exactly how the CSV files in
data/ were obtained or derived from TON_IoT (selection, sub-sampling,
column mapping), and which licence applies.

[1] Alsaedi, A.; Moustafa, N.; Tari, Z.; Mahmood, A.; Anwar, A.
    "TON_IoT Telemetry Dataset", IEEE Access (2020).
[2] OASIS  MQTT v5.0 Standard.

PAPER -> CSV COLUMN MAPPING  (Eq. 1)
==============================================================================
Equation 1 enumerates 4 header fields + 6 payload fields + 4 metadata fields:

    HEADER  (|A_header| = 4)
    +-----------------+--------------------------------------------+
    | Paper symbol    | Source in TON_IoT (CSV/synth)              |
    +-----------------+--------------------------------------------+
    | topic_i         | synth: "scada/<device_type>/<id>/telemetry"|
    | client_id_i     | device_id column                           |
    | QoS_i           | synth: 1 (MQTT v5 at-least-once, default)  |
    | t_i^broker      | timestamp / ts column                      |
    +-----------------+--------------------------------------------+

    PAYLOAD (|A_payload| = 6)
    +-----------------+--------------------------------------------+
    | Paper symbol    | Source in TON_IoT (CSV/synth)              |
    +-----------------+--------------------------------------------+
    | M_i^num         | numeric vector (temperature, humidity,     |
    |                 | pressure, voltage, current, power)         |
    | S_i^cat         | status column (normal/warning/critical)    |
    | L_i^(loc)       | synth: device installation zone label      |
    | type_i          | device_type column                         |
    | t_i^device      | ts column (device-side capture timestamp)  |
    | device_id_i     | device_id column                           |
    +-----------------+--------------------------------------------+

    METADATA  (|m_k| = 4)  -- appended by C1 at intercept time:
        _edge_ts, _source_id, _stream_seq, _volatile_flag

    GROUND TRUTH (NOT exposed to C3/C4/C5):
        label    -- 0 benign, 1 anomalous
        attack_type -- normal | injection | dos | ddos | malformed |
                       backdoor | scanning | tampering

AUXILIARY MQTT v5.0 PROTOCOL FIELDS  (kept alongside the 4 canonical
header fields so that rule r3 in Eq.3 can perform conformance checks
per OASIS spec; these are NOT counted in n=10):
    keep_alive (default 60), remaining_length (default 64)
"""

import csv
import glob
import random
import time
from pathlib import Path


# =========================================================================
# Per-device-type criticality / zone registry for C4 (Eq. 4)
#   crit_i : NIST SP 800-30 Rev.1   (Low 0.0 / Mod 0.5 / High 1.0)
#   zone_i : IEC 62443-3-3 zones    (Low 0.0 / Mod 0.5 / High 1.0)
# =========================================================================
# These values feed C4 (Eq. 4): c_i = 0.5*crit + 0.5*zone.  With the default
# theta_context = 0.5, a device type whose (crit, zone) sums to less than 1.0
# (c_i < 0.5) can NEVER be sealed.  That is the case for "light" and "weather"
# (both 0.0) - their own telemetry is never captured, whatever the anomaly
# score.  The values are expert assignments, not learned from data.
DEVICE_TYPE_REGISTRY = {
    # device_type    : (criticality, zone)
    "modbus":      (1.0, 1.0),   # PLC/RTU control bus            -- HIGH
    "thermostat":  (1.0, 0.5),   # HVAC actuator                  -- HIGH
    "fridge":      (0.5, 0.5),   # cold-chain monitoring          -- MOD
    "garage_door": (0.5, 0.5),   # physical-security actuator     -- MOD
    "motion_light":(0.5, 0.5),   # safety lighting                -- MOD
    "light":       (0.0, 0.0),   # decorative IoT                 -- LOW
    "weather":     (0.0, 0.0),   # ambient sensor                 -- LOW
    "gps_tracker": (0.5, 1.0),   # tracking, internet-exposed     -- MOD/HIGH
}

# Static device->location synthesis for L_i^(loc) (paper Eq.1)
ZONE_LABELS = {
    "modbus":       "plant_floor_zoneA",
    "thermostat":   "control_room_zoneB",
    "fridge":       "cold_storage_zoneC",
    "garage_door":  "perimeter_zoneD",
    "motion_light": "perimeter_zoneD",
    "light":        "office_zoneE",
    "weather":      "outdoor_zoneF",
    "gps_tracker":  "mobile_zoneG",
}


def _normalize_device_type(raw: str) -> str:
    # Map any free-text device type onto one of the 8 registry keys by
    # substring match (dict order matters: "motion_light" is tested before
    # "light").  Unknown types fall back to "weather" (lowest priority).
    s = (raw or "").lower().replace(" ", "_")
    for k in DEVICE_TYPE_REGISTRY:
        if k in s:
            return k
    return "weather"      # safe low-priority default


# =========================================================================
# Per-device-type CSV column -> M_num mapping
# -------------------------------------------------------------------------
# The TON_IoT IoT subset files used here share a UNIFIED schema:
#   timestamp, device_id, device_type, temperature, humidity, pressure,
#   voltage, current, power, status, label
#
# So the canonical mapping (used for all 8 device families) is:
#   M_i^num.primary    <-  temperature      ->  feeds Eq.2  f1
#   M_i^num.secondary  <-  humidity         ->  feeds Eq.2  f2
#   M_i^num.tertiary   <-  pressure         ->  feeds Eq.2  f3
#   M_i^num.voltage    <-  voltage
#   M_i^num.current    <-  current
#   M_i^num.power      <-  power
#
# Some published TON_IoT variants ship per-subset columns
# (fridge_temperature, FC1_Read_Input_Register, current_temperature, ...);
# the fallback map below resolves those names to the canonical triplet
# so the same loader works for both variants.
# =========================================================================
# Only used when the unified columns temperature/humidity/pressure are absent
# (original per-subset TON_IoT files).  The shipped CSVs use the unified
# schema, so this table is not exercised in the paper experiments.
SUBSET_NUMERIC_MAP_FALLBACK = {
    "fridge":      ("fridge_temperature",        "temp_condition_num",  "pressure"),
    "gps_tracker": ("latitude",                  "longitude",            "pressure"),
    "garage_door": ("door_state_num",            "sphone_signal",        "pressure"),
    "light":       ("motion_status_num",         "light_status_num",     "pressure"),
    "modbus":      ("FC1_Read_Input_Register",   "FC2_Read_Discrete_Value",
                                                 "FC3_Read_Holding_Register"),
    "motion_light":("motion_status_num",         "light_status_num",     "pressure"),
    "thermostat":  ("current_temperature",       "thermostat_status_num","pressure"),
    "weather":     ("temperature",               "humidity",             "pressure"),
}


def _resolve_numeric_triplet(row: dict, device_type: str):
    """Return (primary, secondary, tertiary) numeric values, trying the
    UNIFIED schema first and falling back to the per-subset names.
    """
    # ----- 1. Canonical unified schema (what the supplied CSVs use) -----
    def _try(key):
        # float(value) if possible, categorical code if not, None if empty.
        v = row.get(key)
        if v in (None, ""):
            return None
        try:
            return float(v)
        except (TypeError, ValueError):
            return _encode_categorical(v)

    primary   = _try("temperature")
    secondary = _try("humidity")
    tertiary  = _try("pressure")
    if primary is not None and secondary is not None and tertiary is not None:
        return primary, secondary, tertiary

    # ----- 2. Per-subset fallback for split-schema variants -------------
    cols = SUBSET_NUMERIC_MAP_FALLBACK.get(device_type,
                                           SUBSET_NUMERIC_MAP_FALLBACK["weather"])
    return (_try(cols[0]) or 0.0,
            _try(cols[1]) or 0.0,
            _try(cols[2]) or 0.0)


def _encode_categorical(value):
    """Convert a categorical string to a stable numeric code (consistent across rows)."""
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        # CAUTION: Python's built-in hash() of a str is salted per process
        # (PYTHONHASHSEED), so this code is NOT stable across runs despite the
        # comment below.  It is never reached with the shipped CSVs (all
        # numeric columns parse as floats).  To make it deterministic use
        # e.g. zlib.crc32(value.encode()) instead.
        # stable hash-based encoding (avoids per-run randomness)
        return float(abs(hash(str(value).strip().lower())) % 1000) / 10.0


def _to_event(row: dict, seq: int, device_type_hint: str) -> dict:
    """Convert a TON_IoT CSV row to a CAEF MQTT event.

    Each event carries the EXACT 4 header + 6 payload + 4 metadata layout
    of paper Eq.1, plus 2 auxiliary MQTT v5 protocol fields (keep_alive,
    remaining_length) required by rule r3 in Eq.3.
    """
    # --- identity -------------------------------------------------------
    device_id   = (row.get("device_id") or f"dev_{seq}").strip()
    device_type = _normalize_device_type(
        row.get("device_type") or device_type_hint
    )

    def _num(key, default=0.0):
        # Read a numeric CSV cell; empty -> default; text -> categorical code.
        v = row.get(key)
        try:
            return float(v) if v not in (None, "") else default
        except (TypeError, ValueError):
            return _encode_categorical(v)

    # ---- Extract M_num triplet (paper Eq.1's primary/secondary/tertiary) -
    m_num_primary, m_num_secondary, m_num_tertiary = \
        _resolve_numeric_triplet(row, device_type)

    # Electrical sub-vector (additional numeric channels of M_num).
    # These three channels are carried in the event but not used by C2/C3.
    m_num_voltage = _num("voltage")
    m_num_current = _num("current")
    m_num_power   = _num("power")

    ev = {
        # ====================================================================
        # A_i^(header)  --  |.| = 4   (paper Eq.1)
        # ====================================================================
        "topic":      f"scada/{device_type}/{device_id}/telemetry",   # topic_i
        "client_id":  device_id,                                       # client_id_i
        "QoS":        1,                                               # QoS_i (default at-least-once)
        "broker_ts":  row.get("timestamp") or row.get("ts") or time.time(),   # t_i^broker

        # ---- Auxiliary MQTT v5.0 protocol fields needed for rule r3 ------
        "keep_alive":       60,
        "remaining_length": 64,

        # ====================================================================
        # A_i^(payload)  --  |.| = 6   (paper Eq.1)
        # ====================================================================
        # 1) M_i^num : numeric measurements vector
        "numeric_primary":      m_num_primary,
        "numeric_secondary":    m_num_secondary,
        "numeric_tertiary":     m_num_tertiary,
        "numeric_electrical_v": m_num_voltage,
        "numeric_electrical_i": m_num_current,
        "numeric_electrical_p": m_num_power,
        # 2) S_i^cat : categorical state
        "status":               (row.get("status") or "normal").strip(),
        # 3) L_i^(loc) : location label (synthesised from device_type)
        "location":             ZONE_LABELS.get(device_type, "unknown_zone"),
        # 4) type_i : event type (= device family)
        "device_type":          device_type,
        # 5) t_i^device : device-side timestamp
        "device_ts":            row.get("ts") or row.get("timestamp") or time.time(),
        # 6) device_id_i
        "device_id":            device_id,

        # ====================================================================
        # GROUND TRUTH  (NEVER seen by C3/C4/C5 -- only by evaluation.py)
        # ====================================================================
        # Native CSV label: 1 -> relabelled "tampering".  In the shipped CSVs
        # this label is statistically independent of every numeric column
        # (AUC ~ 0.50), so these rows are essentially undetectable.
        "label":        int(_num("label", 0.0)),
        "attack_type":  "tampering" if int(_num("label", 0.0)) == 1
                                    else "normal",
    }
    return ev


def load_ton_iot(path: str, max_rows: int = None) -> tuple[list, dict]:
    """Read every Train_Test_IoT_*.csv in `path` (or one file) and return
    (events, device_registry).  Files are read in sorted name order, one after
    the other (no interleaving).  max_rows truncates the whole stream."""
    p = Path(path)
    if p.is_dir():
        files = sorted(glob.glob(str(p / "Train_Test_IoT_*.csv")))
    else:
        files = [str(p)]
    if not files:
        raise FileNotFoundError(f"No TON_IoT CSV found at {path}")

    print(f"[loader] reading {len(files)} TON_IoT file(s) ...")
    events = []
    seq = 0
    for fp in files:
        hint = Path(fp).stem.replace("Train_Test_IoT_", "")
        with open(fp, newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                events.append(_to_event(row, seq, hint))
                seq += 1
                if max_rows is not None and seq >= max_rows:
                    break
        print(f"  + {Path(fp).name:<35s}  cumulative={seq}")
        if max_rows is not None and seq >= max_rows:
            break

    # device_registry: client_id -> (criticality, zone) of its device TYPE.
    # Consumed by C4 (Eq. 4).
    device_registry = {}
    for ev in events:
        if ev["client_id"] not in device_registry:
            device_registry[ev["client_id"]] = DEVICE_TYPE_REGISTRY[
                ev["device_type"]
            ]

    print(f"[loader] total events loaded : {len(events):,}")
    print(f"[loader] unique devices       : {len(device_registry):,}")
    return events, device_registry


# =========================================================================
# Synthetic TON_IoT-style stream
# -------------------------------------------------------------------------
# Produces 8 IoT-device subsets with the unified schema assumed by the
# paper's Eq.2 (temperature, humidity, pressure as primary/secondary/
# tertiary numeric measurements).  Used when the real CSV files are not
# present; the distribution is realistic enough to demonstrate the full
# C1..C7 pipeline.
# =========================================================================
def make_ton_iot_synthetic(n_per_device: int = 12200, seed: int = 42) -> tuple[list, dict]:
    """Generate ~97,600 (= 8 * 12,200) synthetic TON_IoT-style events.

    Fallback used only when no CSV directory exists.  Unlike the CSV files it
    gives every device type its own Gaussian baseline (non-identical sites) and
    makes the 1 % native anomalies shift one channel by +15..30 units."""
    rng = random.Random(seed)
    events = []
    device_registry = {}
    seq = 0
    # Per-device-type baseline characteristics (mu, sigma) for the
    # three primary numeric channels and the electrical channels.
    BASELINES = {
        "fridge":       {"t": (4.0, 1.5), "h": (45.0, 5.0), "p": (1013, 5),
                         "v": (230, 5), "c": (1.5, 0.3), "p_w": (50, 8)},
        "gps_tracker":  {"t": (25.0, 3.0), "h": (60.0, 8.0), "p": (1005, 10),
                         "v": (3.7, 0.1), "c": (0.3, 0.05), "p_w": (1.1, 0.2)},
        "garage_door":  {"t": (22.0, 2.0), "h": (55.0, 7.0), "p": (1012, 4),
                         "v": (230, 5), "c": (0.5, 0.1), "p_w": (15, 5)},
        "light":        {"t": (24.0, 1.5), "h": (50.0, 6.0), "p": (1013, 3),
                         "v": (230, 5), "c": (0.2, 0.05), "p_w": (10, 3)},
        "modbus":       {"t": (45.0, 3.0), "h": (40.0, 5.0), "p": (1015, 5),
                         "v": (240, 4), "c": (3.5, 0.4), "p_w": (200, 30)},
        "motion_light": {"t": (24.0, 2.0), "h": (52.0, 6.0), "p": (1013, 3),
                         "v": (230, 5), "c": (0.2, 0.05), "p_w": (12, 3)},
        "thermostat":   {"t": (21.0, 1.0), "h": (45.0, 4.0), "p": (1014, 3),
                         "v": (24.0, 1.0), "c": (1.0, 0.2), "p_w": (24, 5)},
        "weather":      {"t": (20.0, 6.0), "h": (60.0, 12.0), "p": (1013, 8),
                         "v": (12.0, 0.5), "c": (0.1, 0.02), "p_w": (1.2, 0.3)},
    }
    DEVICES_PER_TYPE = 6   # 6 distinct device_ids per family
    print(f"[synth] generating TON_IoT-style stream: 8 device types x "
          f"{n_per_device:,} events = {8 * n_per_device:,} total events")
    for dtype, base in BASELINES.items():
        for d in range(DEVICES_PER_TYPE):
            dev_id = f"{dtype}_{d:02d}"
            device_registry[dev_id] = DEVICE_TYPE_REGISTRY[dtype]
        per_dev = n_per_device // DEVICES_PER_TYPE
        for d in range(DEVICES_PER_TYPE):
            dev_id = f"{dtype}_{d:02d}"
            for i in range(per_dev):
                # 1% native TON_IoT label=1 anomalies (will be tagged
                # "tampering" so OIF can pick them up later).
                anomalous = rng.random() < 0.01
                noise_t = rng.gauss(0, base["t"][1])
                noise_h = rng.gauss(0, base["h"][1])
                noise_p = rng.gauss(0, base["p"][1])
                if anomalous:
                    # tamper with one channel only (subtle drift,
                    # statistical signature -> OIF)
                    if rng.random() < 0.5:
                        noise_t += rng.uniform(15, 30)
                    else:
                        noise_h += rng.uniform(15, 30)
                ev = {
                    "topic":      f"scada/{dtype}/{dev_id}/telemetry",
                    "client_id":  dev_id,
                    "QoS":        1,
                    "broker_ts":  time.time() + seq * 0.001,
                    "keep_alive": 60,
                    "remaining_length": 64,
                    "numeric_primary":      base["t"][0] + noise_t,
                    "numeric_secondary":    base["h"][0] + noise_h,
                    "numeric_tertiary":     base["p"][0] + noise_p,
                    "numeric_electrical_v": base["v"][0] + rng.gauss(0, base["v"][1]),
                    "numeric_electrical_i": base["c"][0] + rng.gauss(0, base["c"][1]),
                    "numeric_electrical_p": base["p_w"][0] + rng.gauss(0, base["p_w"][1]),
                    "status":     "warning" if anomalous else "normal",
                    "location":   ZONE_LABELS[dtype],
                    "device_type": dtype,
                    "device_ts":  time.time() + seq * 0.001,
                    "device_id":  dev_id,
                    "label":      1 if anomalous else 0,
                    "attack_type": "tampering" if anomalous else "normal",
                }
                events.append(ev)
                seq += 1
    rng.shuffle(events)
    print(f"[synth] generated {len(events):,} events across "
          f"{len(device_registry):,} devices")
    return events, device_registry


# Backwards-compat alias
make_synthetic_stream = make_ton_iot_synthetic
