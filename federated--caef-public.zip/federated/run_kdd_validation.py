"""
run_kdd_validation.py
=====================
Independent-dataset validation: runs the unchanged CAEF pipeline (baseline C3
and federated C3, Eq. 8) and the FCA baseline on KDD Cup 99, over several
seeds, with the same metrics as run_multi_seed.py.

Input     : data/kdd/KDDCup99.csv (see kdd_loader.py for the column mapping).
Protocols : --protocol injected the TON_IoT attack process applied to KDD: only
                                the normal records (97,277) form the background, the
                                six attack classes of attack_injector.py are injected
                                with the same mix and burst geometry; only injected
                                events count as attacks (native KDD attacks are not used)
            --protocol matched  (default) all normal rows + a random attack
                                subsample so attacks are 22.4 % of the stream
                                (the share used for TON_IoT)
            --protocol natural  all unique rows, 39.7 % attacks
Registry  : --registry policy (default) per-site criticality/zone of
            kdd_loader.SITE_REGISTRY;  --registry flat: every site (0.5, 0.5)
Seeds     : the seed controls the attack subsample (matched) and the arrival
            order; the Isolation Forest random_state stays fixed.
Outputs   : kdd_<protocol>_<registry>_results.json (per-seed records and
            summary), kdd_<protocol>_<registry>_summary.csv.
Usage     : python run_kdd_validation.py --csv data/kdd/ --seeds 42-51
"""

import argparse
import contextlib
import random
import csv
import io
import json
import statistics as st
import time

import numpy as np

import run_fca_evaluation as fca
from caef import CAEFPipeline, CONFIG
from federated_caef import FedC3_AnomalyDetectionEngine
import attack_injector as inj
from attack_injector import inject_attacks, DEFAULT_ATTACK_MIX
from evaluation import print_report
from kdd_loader import (load_kdd, make_stream, describe, REGISTRY_FLAT,
                        SITE_REGISTRY, NUMERIC_FEATURES)
from privacy_metrics import (communication_cost_metric,
                             mutual_information_leakage_metric)
from run_multi_seed import parse_seeds

BROKER_DELAY_NS = 12_000_000     # constant simulated broker delay (as elsewhere)
FAMILIES = ("dos", "probe", "r2l", "u2r")

# Mean / SD of the three TON_IoT channels (temperature, humidity, pressure) that
# the injector's absolute offsets and ranges were written for.  For KDD the same
# attacks are expressed in standard deviations of the corresponding KDD channel.
TON_SD = (11.53, 23.07, 14.42)
TON_MU = (10.0, 59.99, 12225.0)


def install_scaled_injector(background):
    """Re-define the injector's backdoor and scanning magnitudes in units of the
    channel standard deviation, so the injected z-scores equal those used for
    TON_IoT.  Random draws (and their order) are unchanged."""
    import numpy as np
    keys = ("numeric_primary", "numeric_secondary", "numeric_tertiary")
    mu = [float(np.mean([e[k] for e in background])) for k in keys]
    sd = [float(np.std([e[k] for e in background])) for k in keys]

    def backdoor(base):
        import copy
        ev = copy.deepcopy(base)
        ev["numeric_primary"] += random.uniform(40.0, 80.0) / TON_SD[0] * sd[0]
        ev["numeric_secondary"] += random.uniform(30.0, 60.0) / TON_SD[1] * sd[1]
        ev["label"], ev["attack_type"] = 1, "backdoor"
        return ev

    def scanning(base):
        import copy
        ev = copy.deepcopy(base)
        for k, (lo, hi), i in ((keys[0], (-200.0, 300.0), 0), (keys[1], (-150.0, 250.0), 1),
                               (keys[2], (0.0, 99_999.0), 2)):
            ev[k] = mu[i] + (random.uniform(lo, hi) - TON_MU[i]) / TON_SD[i] * sd[i]
        ev["label"], ev["attack_type"] = 1, "scanning"
        return ev
    inj.make_backdoor, inj.make_scanning = backdoor, scanning

# The FCA baseline scores events with the dataset's own label as ground truth.
fca.ground_truth_label = lambda ev, mode="injected": int(ev["label"])


def run_pass(events, registry, fed, fed_lambda=1.0):
    """One pass of the stream through C1..C7 (fed=True: federated C3)."""
    p = CAEFPipeline(device_registry=registry)
    if fed:
        p.c3 = FedC3_AnomalyDetectionEngine(site_key="device_type",
                                            fed_lambda=fed_lambda)
    for ev in events:
        p.ingest(dict(ev), source_id="edge_node_01", true_label=int(ev["label"]),
                 t_broker_ns=time.time_ns() - BROKER_DELAY_NS)
    with contextlib.redirect_stdout(io.StringIO()):
        res = print_report(decisions=p.all_decisions, latencies_ns=p.latencies_ns,
                           wall_clock_s=1.0, total_events=p.total_events)
    # recall per raw attack name (JSON only)
    by_name = {}
    for ev, d in zip(events, p.all_decisions):
        if ev["label"] == 1:
            nm = ev.get("attack_name", "normal")
            e = by_name.setdefault(nm if nm != "normal" else ev["attack_type"], [0, 0])
            e[0] += 1
            e[1] += d["d_i"]
    res["per_attack_name"] = {k: {"total": v[0], "detected": v[1]}
                              for k, v in by_name.items()}
    return res, p


def run_fca(events):
    """FCA baseline (batch Isolation Forest, contamination 0.10) on the same stream."""
    with contextlib.redirect_stdout(io.StringIO()):
        return fca.run_fca_pipeline(events)


def f1(prec, rec):
    return 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/kdd/")
    ap.add_argument("--seeds", default="42-51")
    ap.add_argument("--protocol", choices=["matched", "natural", "injected"], default="matched")
    ap.add_argument("--registry", choices=["policy", "flat"], default="policy")
    ap.add_argument("--fed-lambda", type=float, default=1.0,
                    help="damping lambda of Eq. 8b; 0 = local-only control (no shared threshold)")
    ap.add_argument("--keep-duplicates", action="store_true")
    ap.add_argument("--tag", default=None)
    args = ap.parse_args()
    tag = args.tag or f"kdd_{args.protocol}_{args.registry}"

    injected = args.protocol == "injected"
    all_events, registry = load_kdd(args.csv, dedup=(not args.keep_duplicates) and not injected)
    if injected:
        all_events = [e for e in all_events if e["label"] == 0]
        install_scaled_injector(all_events)
        print(f"[kdd] injected protocol: background = {len(all_events):,} normal records")
    if args.registry == "flat":
        registry = {c: REGISTRY_FLAT[c.rsplit("_", 1)[0]] for c in registry}
    print(f"[kdd] columns used: {len(NUMERIC_FEATURES)} numeric + service/flag "
          f"(of 41 + label);  sites K = {len({e['device_type'] for e in all_events})},"
          f" clients = {len(registry)}")

    records = []
    for seed in parse_seeds(args.seeds):
        if injected:
            events = list(all_events)
            random.Random(seed).shuffle(events)
            with contextlib.redirect_stdout(io.StringIO()):
                events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX, seed=seed)
        else:
            events = make_stream(all_events, seed, args.protocol)
        base, _ = run_pass(events, registry, fed=False)
        fed, pf = run_pass(events, registry, fed=True, fed_lambda=args.fed_lambda)
        fc = run_fca(events)
        priv = pf.c3.export_privacy_metric_data()
        comm = communication_cost_metric(
            K=priv["K"], R=priv["R"],
            per_site_event_counts=priv["per_site_event_counts"], d=10)
        mi = mutual_information_leakage_metric(priv["mi_rows"])
        rec = {
            "seed": seed, "events": len(events),
            "attack_rows": base["m2_volatile"],
            "PR_base": base["m2_PR"], "PR_fed": fed["m2_PR"], "PR_fca": fc["m2_PR"],
            "prec_base": base["m3_precision"], "prec_fed": fed["m3_precision"],
            "prec_fca": fc["m3_precision"],
            "F1_base": f1(base["m3_precision"], base["m2_PR"]),
            "F1_fed": f1(fed["m3_precision"], fed["m2_PR"]),
            "F1_fca": f1(fc["m3_precision"], fc["m2_PR"]),
            "TP_base": base["m3_TP"], "FP_base": base["m3_FP"],
            "TP_fed": fed["m3_TP"], "FP_fed": fed["m3_FP"],
            "lat_base_ms": base["m1_mean_ms"], "lat_fed_ms": fed["m1_mean_ms"],
            "per_class_base": base["per_class"], "per_class_fed": fed["per_class"],
            "per_class_fca": fc["per_class"],
            "per_attack_name_base": base["per_attack_name"],
            "R": priv["R"], "Cost_FL": comm["Cost_FL_bytes"],
            "Cost_central": comm["Cost_centralized_bytes"],
            "MI_nats": mi.get("I_XB_Gt_nats"),
            "MI_all_rows_nats": mi.get("I_all_rows_nats"),
            "MI_null_p95": mi.get("permutation_null_p95_nats"),
            "MI_null_mean": mi.get("permutation_null_mean_nats"),
            "MI_rows_used": mi.get("n_rows_used"),
            "MI_per_feature": mi.get("mi_per_feature_nats"),
        }
        records.append(rec)
        print(f"seed {seed}: n={rec['events']:,}  PR {rec['PR_base']*100:.2f}->"
              f"{rec['PR_fed']*100:.2f} (FCA {rec['PR_fca']*100:.2f})  prec "
              f"{rec['prec_base']:.4f}->{rec['prec_fed']:.4f} (FCA {rec['prec_fca']:.4f})  "
              f"MI {rec['MI_nats']:.3f} (null p95 {rec['MI_null_p95']:.3f})", flush=True)

    keys = [k for k in records[0] if isinstance(records[0][k], (int, float))
            and k != "seed"]
    summary = {}
    for k in keys:
        v = [r[k] for r in records if r[k] is not None]
        summary[k] = {"mean": float(np.mean(v)),
                      "sd": float(st.stdev(v)) if len(v) > 1 else 0.0,
                      "min": float(min(v)), "max": float(max(v))}
    for name, a, b in (("delta_PR_points", "PR_fed", "PR_base"),
                       ("delta_precision", "prec_fed", "prec_base")):
        mult = 100 if "PR" in name else 1
        d = [(r[a] - r[b]) * mult for r in records]
        summary[name] = {"mean": float(np.mean(d)),
                         "sd": float(st.stdev(d)) if len(d) > 1 else 0.0}
    summary["per_class_recall"] = {}
    fams = sorted({c for r in records for c in r["per_class_base"]} - {"normal"})
    for fam in fams:
        for tag2 in ("base", "fed", "fca"):
            v = [r[f"per_class_{tag2}"][fam]["detected"] / r[f"per_class_{tag2}"][fam]["total"]
                 for r in records if r[f"per_class_{tag2}"].get(fam, {}).get("total")]
            if v:
                summary["per_class_recall"][f"{fam}_{tag2}"] = {
                    "mean": float(np.mean(v)),
                    "sd": float(st.stdev(v)) if len(v) > 1 else 0.0,
                    "n_mean": float(np.mean([r["per_class_base"][fam]["total"]
                                             for r in records
                                             if fam in r["per_class_base"]]))}
    summary["above_null"] = sum(1 for r in records if r["MI_nats"] > r["MI_null_p95"])
    summary["dataset"] = describe(all_events)
    summary["attack_types"] = {c: float(np.mean([r["per_class_base"][c]["total"] for r in records if c in r["per_class_base"]])) for c in fams}
    summary["protocol"] = args.protocol
    summary["registry"] = args.registry

    with open(f"{tag}_results.json", "w") as fh:
        json.dump({"records": records, "summary": summary}, fh, indent=2)
    with open(f"{tag}_summary.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["metric", "mean", "sd", "min", "max"])
        for k, v in summary.items():
            if k == "per_class_recall":
                for kk, vv in v.items():
                    w.writerow([f"recall_{kk}", vv["mean"], vv["sd"], "", ""])
            elif isinstance(v, dict) and "mean" in v:
                w.writerow([k, v["mean"], v["sd"], v.get("min", ""), v.get("max", "")])

    print(f"\n===== {tag}: mean +/- sd over {len(records)} seeds =====")
    for k in ("events", "attack_rows", "PR_base", "PR_fed", "PR_fca",
              "prec_base", "prec_fed", "prec_fca", "F1_base", "F1_fed", "F1_fca",
              "delta_PR_points", "delta_precision", "lat_base_ms", "lat_fed_ms",
              "MI_nats", "MI_all_rows_nats", "MI_null_p95", "R"):
        s = summary[k]
        print(f"{k:18s} {s['mean']:14.4f} +/- {s['sd']:.4f}")
    print("\nper-family recall (mean +/- sd, %, mean n):")
    for k, v in summary["per_class_recall"].items():
        print(f"  {k:12s} {v['mean']*100:8.2f} +/- {v['sd']*100:5.2f}   n = {v['n_mean']:.0f}")
    print(f"\nseeds with MI above the 95th percentile of the null: "
          f"{summary['above_null']} of {len(records)}")
    r0 = records[0]
    print(f"R = {r0['R']}, Cost_FL = {r0['Cost_FL']:,} B, Cost_centralized = "
          f"{r0['Cost_central']:,} B, reduction = {r0['Cost_central']/r0['Cost_FL']:,.1f}x")


if __name__ == "__main__":
    main()
