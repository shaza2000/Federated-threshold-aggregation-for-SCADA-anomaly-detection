# CAEF — reference implementation and federated extension (simulation)

Python implementation of the federated threshold-aggregation extension (Eq. 8a–8c), the two
privacy metrics, the data loaders, the attack injector and the evaluation drivers, evaluated on a
simulated MQTT stream.  Everything runs in one process: the "broker" delay is a constant 12 ms that is
added to every latency, and the timestamping authority is simulated.

## Base detection module (not included)
The extension subclasses the per-site detection pipeline in `caef.py`, which is **not part of this
repository**.  The drivers (`run_simulation.py`, `run_multi_seed.py`, `run_kdd_validation.py`,
`tune_parameters.py`, `fig3_class_means.py`) need that module in the same folder to run; it is
available to editors and reviewers on request.  Without it, `check_paper_numbers.py` still compares
the stored result files with the paper's numbers.

## Quick start
```bash
pip install -r requirements.txt            # numpy, pandas, scikit-learn
# put the eight device-type CSV files into data/  (see data/README.md)
python run_simulation.py --csv data/ --seed 42     # baseline vs federated, one seed
python run_multi_seed.py --csv data/ --seeds 42-51 # mean +/- sd over ten seeds
```
Results are deterministic: rule r2 uses a virtual clock
(`CONFIG["r2_clock"] = "virtual"`, `sim_event_rate_hz = 1000`), the Isolation Forest uses a
fixed random_state, and only the attack placement depends on `--seed`.

## Reproducing every number in the paper
```bash
python run_simulation.py     --csv data/ --seed 42      # seed-42 terminal report, results*.json
python run_multi_seed.py     --csv data/ --seeds 42-51  # ten-seed mean +/- sd, per-class recall, MI vs null
python run_fca_multi_seed.py --csv data/ --seeds 42-51  # FCA baseline
python fig3_class_means.py   --csv data/ --seed 42      # class means quoted in the Limitations section
python tune_parameters.py    --csv data/ --seed 42      # 324-configuration sensitivity grid (~10 min)
python check_paper_numbers.py                           # 138 paper-vs-measurement checks, exit code 1 on mismatch
```
Latency values depend on the machine (the check uses a 0.1 ms tolerance); everything else is deterministic.
Logs of the runs used for the paper are included (`*_log.txt`, `check_paper_numbers_output.txt`).

## Independent-dataset validation (KDD Cup 99)
```bash
# put KDDCup99.csv into data/kdd/  (see data/README.md)
python run_kdd_validation.py --protocol matched --seeds 42-51                  # attacks = 22.4 % of the stream
python run_kdd_validation.py --protocol injected --seeds 42-51                 # TON_IoT attack process on the KDD normal records
python run_kdd_validation.py --protocol injected --fed-lambda 0 --tag kdd_injected_localonly
python run_kdd_validation.py --protocol natural --seeds 42-51                  # all unique records, 39.7 % attacks
python run_kdd_validation.py --protocol matched --registry flat --tag kdd_matched_flat   # context-registry ablation
python run_kdd_validation.py --protocol matched --fed-lambda 0 --tag kdd_matched_localonly  # no shared threshold
python run_multi_seed.py --csv data/ --fed-lambda 0 --out-json multi_seed_localonly.json --out-csv multi_seed_localonly.csv
```
`kdd_loader.py` derives each Eq. 1 field from a KDD column (no rule reads the label):

| Eq. 1 field | TON_IoT-format column | KDD Cup 99 column / rule |
|---|---|---|
| M_num primary, secondary, tertiary (f1, f2, f3) | temperature, humidity, pressure | log(1+src_bytes), log(1+dst_bytes), count |
| M_num carried only | voltage, current, power | serror_rate, rerror_rate, same_srv_rate |
| S_cat | status | flag |
| client_id / device_id | device_id | `<site>_<k>`, k = 0-5 in turn within a site |
| site (type_i) | device type (8) | 7 most frequent services + "misc" (8) |
| topic_i (rule r1) | `scada/<type>/<id>/telemetry` | `unauthorized/...` if land, urgent, failed logins, root shell or su attempt |
| keep_alive (rule r3) | constant 60 | -1 if wrong_fragment > 0, else 60 |
| crit_i, zone_i (C4) | registry per device type | registry per site (`SITE_REGISTRY`) |
| ground truth | injected attack classes | label != normal |
  No detector parameter is retuned.  Results (mean ± sd over seeds 42–51), also in
`kdd_*_results.json`, `kdd_*_summary.csv` and `kdd_*_log.txt`:

| | KDD matched | KDD natural |
|---|---|---|
| CAEF baseline PR / precision / F1 | 18.92 % / 0.179 / 0.184 | 17.37 % / 0.290 / 0.217 |
| Federated PR / precision / F1 | 72.31 % / 0.364 / 0.484 | 84.06 % / 0.586 / 0.690 |
| Local-only (lambda = 0) PR | 20.85 % | 26.54 % |
| FCA baseline PR / precision | 32.69 % / 0.754 | 17.58 % / 0.766 |
| MI estimate vs null 95th pct (nats) | 0.880 vs 0.710 (above in 7 of 10) | 1.220 vs 0.682 (above in 10 of 10) |

Optional extra protocol (not used in the paper): `--protocol injected` replays the TON_IoT attack classes over the KDD normal records; there federation gives no PR gain.
On the native attacks the sites differ strongly in their attack share, and the shared threshold, not the
per-site models, produces the gain.  KDD Cup 99 describes network connections (1999), not MQTT
telemetry; the experiment tests the threshold mechanism on a different data distribution.

## Optional: live MQTT broker demo
The reported numbers come from the in-process simulation.  To send the same attack stream through a
real Eclipse Mosquitto broker (MQTT v5, 127.0.0.1:1883) install the optional requirements and run:
```bash
pip install -r requirements-optional.txt     # adds paho-mqtt and matplotlib
mosquitto -d
python live_broker_test.py                   # publishes the stream and checks that a subscriber receives every message
python mqtt_publisher.py --csv data/<file>.csv   # publisher
```
The federated rounds themselves remain in-process.

## Evaluation definition
* Stream: 97,600 CSV rows (8 device types x 12,200) round-robin interleaved, then attacks
  injected (see `attack_injector.py`), giving 103,360 events (5,760 inserted DoS/DDoS events).
* Ground truth (default `--ground-truth injected`): an event is an attack only if it belongs to
  an injected class (injection, dos, ddos, malformed, backdoor, scanning).  Native label = 1
  rows of the CSV ("tampering") are NOT counted: in the supplied files the label is
  statistically independent of every sensor column.  `--ground-truth all` restores the
  legacy definition.
* Metrics: PR = sealed attacks / attacks; P_trigger = TP / (TP + FP); mean L_E2E includes the
  constant 12 ms simulated broker delay (it is not a network measurement).

## Results, seeds 42–51 (mean ± sample sd), `multi_seed_results.json`
| Metric | Baseline (centralised OIF) | Federated (FedC3) |
|---|---|---|
| PR (%) | 86.16 ± 0.15 | 86.19 ± 0.50 |
| P_trigger | 0.6735 ± 0.0033 | 0.5070 ± 0.0284 |
| Mean L_E2E (ms) | 12.046 ± 0.002 | 12.049 ± 0.002 |

Paired difference federated − baseline: PR +0.03 ± 0.58 points, P_trigger −0.166 ± 0.031.
Communication: R = 25 rounds, Cost_FL = 1,600 B versus 4,134,400 B centralised (2,584x).
Mutual information (KSG estimate, 24 full-window site-round pairs): 0.54 ± 0.17 nats against a
permutation-null 95th percentile of 0.71 ± 0.05 nats; including the 64-event first refits it is
1.49 ± 0.79 nats (confounded by window size).

FCA baseline (one batch Isolation Forest, `run_fca_evaluation.py`, same streams): PR 31.98 ± 1.05 %, P_trigger 0.717 ± 0.024 (`fca_multi_seed_results.json`); its latency is a constant, not a measurement.

Sensitivity grid (`tuning_summary.csv`, 324 configurations, seed 42): PR spans 3.6–88.2 %, precision 0.41–1.00; the F1-optimal setting (alpha 0.3, theta_a 0.20, contamination 0.15) gives PR 83.3 %, precision 0.802, whereas the deployed setting (alpha 0.5, theta_a 0.25, contamination 0.20) favours PR.

Per-class recall (baseline / federated): injection, dos, ddos, malformed 100 % / 100 %;
backdoor 62.4 / 62.8 %; scanning 71.9 / 71.6 %.

## Known limitations (read before quoting results)
1. **Data.** The supplied CSVs have uniform feature distributions, identical statistics across
   device types and a label unrelated to the features; the eight sites are statistically
   identical (IID).  Do not describe them as real measurements without documenting their origin.
2. **Rule r1 sees attacker names.** `SUSPICIOUS_PREFIXES` in `caef.py` match the client ids
   produced by `attack_injector.py`, so protocol-level classes reach 100 % recall by construction.
3. **Context gating.** Device types `light` and `weather` have criticality = zone = 0 in the
   registry, hence c_i = 0 < theta_context and they can never be sealed (an upper bound on PR).
4. **Detector.** `IsolationForest` from scikit-learn refitted on a sliding window (first refit at
   64 events, then every 4096); it is not a streaming Online Isolation Forest.  The score also
   contains clipped floors ((comp-2)/6 and (pairwise-2)/6), a sigmoid slope of 60 and a cold-start
   score comp/8 that are not part of Eq. 3 / 8c.
5. **Eq. 8b** uses lambda = `fed_lambda` = 1.0.
6. **MI metric** is a sum of eight one-dimensional KSG estimates, not a Donsker–Varadhan bound.
7. **r2 clock.** The legacy wall-clock mode (`CONFIG["r2_clock"] = "wall"`) is machine dependent.
8. **Simulation only**: two datasets, none collected from a live SCADA/MQTT deployment; the federated rounds are in-process function calls.

## Files
Core: `federated_caef.py` (Eq. 8a–8c),
`ton_iot_loader.py`, `kdd_loader.py`, `attack_injector.py`, `evaluation.py`, `privacy_metrics.py`.
Broker demo (optional): `live_broker_test.py`, `mqtt_publisher.py`.
Drivers: `run_simulation.py`, `run_multi_seed.py`, `run_fca_multi_seed.py`, `run_kdd_validation.py`,
`fig3_class_means.py`, `tune_parameters.py`, `check_paper_numbers.py`.
Outputs of the current code: `run_simulation_log.txt`, `results*.json`, `multi_seed_*`, `kdd_*`,
`fca_multi_seed_*`, `tuning_*`, `check_paper_numbers_output.txt`.
