"""
evaluation.py
=============
Computes ONLY the three evaluation metrics defined in **Table 2** of the
base-paper methodology (Table 2).  No other metrics are emitted to the
terminal so the report stays faithful to the methodology.

    Metric 1 : End-to-End Capture Latency      L_E2E   (Eq. 9 of [18])
    Metric 2 : Volatile Artifact Preservation Rate   PR
    Metric 3 : Trigger Precision                P_trigger

A 2x2 confusion matrix is computed internally (it is the *derivation* used
to obtain P_trigger) but it is NOT printed.  Only the three numbers above
appear in the final report block.
"""

import numpy as np


# =========================================================================
# Metric 1 : End-to-End Capture Latency  L_E2E      (Eq. 9 of [18])
# -------------------------------------------------------------------------
#   L_E2E(E_i) = t_i^sealed  -  t_i^broker
#   The pipeline records (t_in_ns, t_out_ns) for every sealed event; we
#   report mean and the 95th percentile because Section 3.7.2 stipulates
#   tail-latency guarantees for real-time SCADA forensics.
# =========================================================================
def end_to_end_latency_ms(latencies_ns: list[int]) -> dict:
    # NOTE: latencies exist ONLY for sealed events (d_i = 1).  The drivers
    # subtract a CONSTANT 12 ms "broker delay" from the arrival timestamp, so
    # every value here is about 12 ms + the real processing time (microseconds
    # to a few ms).  The ~12.05 ms mean is therefore dominated by that constant
    # and differs between runs/versions by only a few microseconds.
    if not latencies_ns:
        return {"n": 0, "mean_ms": 0.0, "p95_ms": 0.0}
    arr = np.asarray(latencies_ns, dtype=np.float64) / 1e6   # ns -> ms
    return {
        "n":       int(arr.size),
        "mean_ms": float(arr.mean()),
        "p95_ms":  float(np.percentile(arr, 95)),
    }


# =========================================================================
# Metric 2 : Volatile Artifact Preservation Rate  PR
# -------------------------------------------------------------------------
#   PR = |EA_sealed|  /  |EA_volatile|
#   |EA_volatile|   : ground-truth count of malicious events in the stream
#                     (i.e. events whose true label = 1)
#   |EA_sealed|     : count of those that the pipeline actually sealed
#                     (true positives, d_i = 1 on a malicious event)
# =========================================================================
def preservation_rate(decisions: list[dict]) -> dict:
    # Ground truth: label = 1 events (injected attacks AND the native
    # label = 1 rows of the CSV files).  PR is then simply the recall.
    n_volatile = sum(1 for d in decisions if d["true_label"] == 1)
    n_sealed   = sum(1 for d in decisions if d["true_label"] == 1
                                          and d["d_i"] == 1)
    pr = (n_sealed / n_volatile) if n_volatile > 0 else 0.0
    return {
        "n_volatile": n_volatile,
        "n_sealed":   n_sealed,
        "PR":         pr,
    }


# =========================================================================
# Metric 3 : Trigger Precision  P_trigger
# -------------------------------------------------------------------------
#   P_trigger = TP / (TP + FP)
#   Measures the fraction of triggered captures that were actually
#   malicious.  Directly bounds storage / chain-of-custody overhead.
# =========================================================================
def trigger_precision(decisions: list[dict]) -> dict:
    # tp: sealed events whose label is 1; fp: sealed events whose label is 0.
    tp = sum(1 for d in decisions if d["d_i"] == 1 and d["true_label"] == 1)
    fp = sum(1 for d in decisions if d["d_i"] == 1 and d["true_label"] == 0)
    p  = (tp / (tp + fp)) if (tp + fp) > 0 else 0.0
    return {"TP": tp, "FP": fp, "P_trigger": p}


# =========================================================================
# Reporter
# =========================================================================
def print_report(decisions: list[dict],
                 latencies_ns: list[int],
                 wall_clock_s: float,
                 total_events:  int,
                 ton_iot_rows:  int = None) -> dict:
    """
    Print the final evaluation block.  ONLY the three metrics from Table 2
    are emitted; no extra numbers.  Also returns a dict of the numbers so
    they can be plotted by the caller.
    """
    bar = "=" * 78      # separator line for the printed report
    print()
    print(bar)
    print(" CAEF EVALUATION REPORT  (Table 2 of methodology)")
    print(bar)
    print(f" Total events through C1..C7 : {total_events:,}")
    print(f"   (TON_IoT rows + inserted DoS/DDoS bursts; every TON_IoT")
    print(f"    row is processed, no event is dropped)")
    print(f" Wall-clock pipeline time    : {wall_clock_s:8.3f} s")
    print(f" Throughput                  : {(total_events/wall_clock_s):8.1f} events/s")
    print()

    # ---- Metric 1 ----
    m1 = end_to_end_latency_ms(latencies_ns)
    print(bar)
    print(" Metric 1 : End-to-End Capture Latency        L_E2E   (Eq. 9)")
    print(bar)
    print(f"   Sealed events    : {m1['n']:,}")
    print(f"   Mean L_E2E       : {m1['mean_ms']:9.3f} ms")
    print(f"   p95  L_E2E       : {m1['p95_ms']:9.3f} ms")
    print()

    # ---- Metric 2 ----
    m2 = preservation_rate(decisions)
    print(bar)
    print(" Metric 2 : Volatile Artifact Preservation Rate   PR")
    print(bar)
    print(f"   |EA_volatile|    : {m2['n_volatile']:,}")
    print(f"   |EA_sealed|      : {m2['n_sealed']:,}")
    print(f"   PR               : {m2['PR']*100:9.2f} %")
    print()

    # ---- Metric 3 ----
    m3 = trigger_precision(decisions)
    print(bar)
    print(" Metric 3 : Trigger Precision   P_trigger = TP / (TP + FP)")
    print(bar)
    print(f"   True positives   : {m3['TP']:,}")
    print(f"   False positives  : {m3['FP']:,}")
    print(f"   P_trigger        : {m3['P_trigger']:9.4f}")
    print(bar)

    # ---- Per-attack-class breakdown (for the chart) ------------------
    # per_class[c]["detected"] counts sealed events with label 1 in class c;
    # for the "normal" class it is therefore always 0 (its sealed events are
    # false positives and are counted in m3_FP instead).
    per_class = {}
    for d in decisions:
        cls = d.get("attack_type", "unknown")
        e = per_class.setdefault(cls, {"total": 0, "detected": 0})
        e["total"]    += 1
        if d.get("true_label", 0) == 1 and d.get("d_i", 0) == 1:
            e["detected"] += 1
        elif d.get("true_label", 0) == 0 and cls == "normal":
            pass  # already counted in total
    # Flat dictionary consumed by the drivers and the chart scripts.
    # NOTE: when ton_iot_rows is None, burst_events is reported as 0.
    return {
        "total_events":  total_events,
        "ton_iot_rows":  ton_iot_rows if ton_iot_rows is not None else total_events,
        "burst_events":  (total_events - ton_iot_rows) if ton_iot_rows else 0,
        "wall_clock_s":  wall_clock_s,
        "throughput":    total_events / wall_clock_s if wall_clock_s > 0 else 0,
        "m1_mean_ms":    m1["mean_ms"],
        "m1_p95_ms":     m1["p95_ms"],
        "m1_sealed":     m1["n"],
        "m2_volatile":   m2["n_volatile"],
        "m2_sealed":     m2["n_sealed"],
        "m2_PR":         m2["PR"],
        "m3_TP":         m3["TP"],
        "m3_FP":         m3["FP"],
        "m3_precision":  m3["P_trigger"],
        "per_class":     per_class,
    }
