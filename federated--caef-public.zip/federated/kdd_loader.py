"""
kdd_loader.py
=============
Adapter that turns the KDD Cup 99 connection records (10 % subset,
494,020 rows, 41 features + label) into CAEF events with the same layout as
paper Eq. 1, so the unchanged C1..C7 pipeline can be run on a second,
independent dataset.

KDD Cup 99 describes TCP/UDP/ICMP connections, not MQTT telemetry, so every
Eq. 1 field is derived from a KDD column by a fixed rule.  NO rule reads the
`label` column; the label is attached only as ground truth for evaluation.

COLUMN -> Eq. 1 MAPPING
==============================================================================
    HEADER
      topic_i        "net/<service>/<client_id>/conn"; becomes
                     "unauthorized/<service>/<client_id>" when the record shows
                     a privilege/authorisation indicator (land = 1, urgent > 0,
                     num_failed_logins > 0, lroot_shell > 0, lsu_attempted > 0)
                     -> rule r1
      client_id_i    "<site>_<k>", k = 0..5 assigned round-robin inside a site
                     in file order (KDD has no host identifier)
      QoS_i          1 (constant)
      t_i^broker     synthetic monotone clock, 1 ms between records
      keep_alive     60, or -1 when wrong_fragment > 0  -> rule r3 (malformed)
      remaining_length 64 (constant)
    PAYLOAD
      M_i^num primary    log1p(src_bytes)     -> f1 of Eq. 2
      M_i^num secondary  log1p(dst_bytes)     -> f2
      M_i^num tertiary   count                -> f3 (connections to the same
                                                host in the last 2 s)
      M_i^num v / i / p  serror_rate, rerror_rate, same_srv_rate (carried only)
      S_i^cat            flag (connection state: SF, S0, REJ, ...)
      L_i^(loc)          "<site>_zone"
      type_i             site name
      device_id_i        client id
    SITES (K = 8): the 7 most frequent `service` values of the de-duplicated
    file (http, private, smtp, domain_u, other, ftp_data, ecr_i) and "misc"
    (all remaining services).  The ranking uses counts only, not labels.
    CONTEXT (C4): per-site (criticality, zone) expert assignment, see
    SITE_REGISTRY; REGISTRY_FLAT gives every site (0.5, 0.5) for an ablation.
    GROUND TRUTH: label != "normal" -> 1; attack_type = DoS / Probe / R2L / U2R
    family; the raw attack name is kept in `attack_name`.

DUPLICATES: 70 % of the raw rows are exact duplicates (a known property of
KDD Cup 99).  By default they are removed before any experiment
(145,585 unique rows).
"""

import csv
import random
from collections import Counter, defaultdict
from pathlib import Path

NUMERIC_FEATURES = ("src_bytes", "dst_bytes", "count", "serror_rate",
                    "rerror_rate", "same_srv_rate")

FAMILY = {}
for _fam, _names in {
    "dos":   ("back", "land", "neptune", "pod", "smurf", "teardrop"),
    "probe": ("ipsweep", "nmap", "portsweep", "satan"),
    "r2l":   ("ftp_write", "guess_passwd", "imap", "multihop", "phf", "spy",
              "warezclient", "warezmaster"),
    "u2r":   ("buffer_overflow", "loadmodule", "perl", "rootkit"),
}.items():
    for _n in _names:
        FAMILY[_n] = _fam

TOP_SERVICES = ("http", "private", "smtp", "domain_u", "other", "ftp_data",
                "ecr_i")
SITES = TOP_SERVICES + ("misc",)

# (criticality, zone) per site, NIST SP 800-30 / IEC 62443-3-3 style levels.
SITE_REGISTRY = {
    "http":     (0.5, 1.0),   # public web server, DMZ
    "smtp":     (0.5, 1.0),   # mail relay, DMZ
    "domain_u": (1.0, 0.5),   # DNS, infrastructure service
    "ftp_data": (0.5, 0.5),   # file transfer
    "private":  (0.5, 0.5),   # unclassified high ports
    "other":    (0.5, 0.5),   # unclassified services
    "ecr_i":    (0.0, 0.0),   # ICMP echo reply, diagnostic traffic
    "misc":     (0.5, 1.0),   # remaining services (telnet, ftp, finger, ...)
}
REGISTRY_FLAT = {s: (0.5, 0.5) for s in SITES}
CLIENTS_PER_SITE = 6


def _f(row, key):
    try:
        return float(row[key])
    except (KeyError, TypeError, ValueError):
        return 0.0


def _to_event(row, seq, site, client):
    import math
    service = row["service"]
    violation = (_f(row, "land") == 1 or _f(row, "urgent") > 0
                 or _f(row, "num_failed_logins") > 0
                 or _f(row, "lroot_shell") > 0 or _f(row, "lsu_attempted") > 0)
    topic = (f"unauthorized/{service}/{client}" if violation
             else f"net/{service}/{client}/conn")
    name = row["label"].strip().rstrip(".")
    fam = FAMILY.get(name)
    return {
        "topic": topic, "client_id": client, "QoS": 1,
        "broker_ts": 1.7e9 + seq * 0.001,
        "keep_alive": -1 if _f(row, "wrong_fragment") > 0 else 60,
        "remaining_length": 64,
        "numeric_primary":      math.log1p(_f(row, "src_bytes")),
        "numeric_secondary":    math.log1p(_f(row, "dst_bytes")),
        "numeric_tertiary":     _f(row, "count"),
        "numeric_electrical_v": _f(row, "serror_rate"),
        "numeric_electrical_i": _f(row, "rerror_rate"),
        "numeric_electrical_p": _f(row, "same_srv_rate"),
        "status": row["flag"],
        "location": f"{site}_zone",
        "device_type": site, "device_id": client,
        "label": 0 if name == "normal" else 1,
        "attack_type": fam if fam else "normal",
        "attack_name": name,
    }


def load_kdd(path, dedup=True):
    """Read KDDCup99.csv (file or directory containing it).  Returns the list
    of events in file order and the per-client registry {client_id: (crit, zone)}."""
    p = Path(path)
    if p.is_dir():
        files = sorted(p.glob("KDD*.csv"))
        if not files:
            raise FileNotFoundError(f"No KDD*.csv found in {path}")
        p = files[0]
    with open(p, newline="") as fh:
        rows = list(csv.DictReader(fh))
    if dedup:
        seen, uniq = set(), []
        for r in rows:
            k = tuple(r.values())
            if k not in seen:
                seen.add(k)
                uniq.append(r)
        rows = uniq
    print(f"[kdd] {p.name}: {len(rows):,} rows"
          + (" (after removing exact duplicates)" if dedup else ""))
    n_site = defaultdict(int)
    events, registry = [], {}
    for i, r in enumerate(rows):
        site = r["service"] if r["service"] in TOP_SERVICES else "misc"
        client = f"{site}_{n_site[site] % CLIENTS_PER_SITE:02d}"
        n_site[site] += 1
        registry[client] = SITE_REGISTRY[site]
        events.append(_to_event(r, i, site, client))
    return events, registry


def make_stream(events, seed, protocol="matched", attack_share=0.2244):
    """Seeded stream construction.
      "natural": all events, random order.
      "matched": all normal events plus a random subsample of attack events so
                 that attacks are `attack_share` of the stream (22.4 %, the
                 share of the TON_IoT stream), random order."""
    rng = random.Random(seed)
    if protocol == "natural":
        out = list(events)
    else:
        normal = [e for e in events if e["label"] == 0]
        attack = [e for e in events if e["label"] == 1]
        n_att = min(len(attack),
                    round(len(normal) * attack_share / (1.0 - attack_share)))
        out = normal + rng.sample(attack, n_att)
    rng.shuffle(out)
    return out


def describe(events):
    """Row/column/class counts for the dataset table."""
    c = Counter(e["attack_type"] for e in events)
    return {"rows": len(events), "attack_rows": sum(1 for e in events if e["label"]),
            "by_family": dict(c)}
