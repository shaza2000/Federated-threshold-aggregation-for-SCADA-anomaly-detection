"""
attack_injector.py
==================
ROLE IN THE SIMULATION ARCHITECTURE  (Section 3.6.2 of the methodology)
=======================================================================
This module is a NAMED component of the CAEF simulation toolset. It is
positioned UPSTREAM of the Eclipse Mosquitto broker, between the TON_IoT
replay source (`ton_iot_loader.py`) and the broker's publish endpoint.
Its role is twofold:

  (1) Data replay & threat streaming, in-process
      ---------------------------------------------------------------
      Given the TON_IoT event list returned by `load_ton_iot()`, it
      programmatically interleaves Section-3.5 attack events with the
      benign baseline to produce a single, deterministic event stream
      ready for ingestion through C1..C7.

  (2) Broker injection, for live broker tests (`broker_inject()`)
      ---------------------------------------------------------------
      The same event stream can be published to a running Eclipse
      Mosquitto broker via paho-mqtt v5.0; the CAEF edge subscriber
      then consumes the broker stream and runs the full C1..C7
      pipeline against it.  This is the path used to validate Eq.9
      end-to-end latency under a real broker.

REPEATABILITY GUARANTEE  (the 5,760 figure in the base paper's evaluation)
=========================================================================
The DoS / DDoS attack-burst counts produced by this module are
COMPILE-TIME constants of the chosen attack-mix.  With the default mix
declared below:

    n_dos_bursts  = max(1, n_dos  // 80)           with n_dos  = 3% of N
    n_ddos_storms = max(1, n_ddos // (8 * 60))     with n_ddos = 3% of N

For N = 97,600 TON_IoT rows (the paper's experiment size):
    n_dos       = 0.03 * 97,600 = 2,928   -->  n_dos_bursts  = 36
    n_dos_total = 36 * 80                 -->  2,880 DoS events
    n_ddos      = 0.03 * 97,600 = 2,928   -->  n_ddos_storms = 6
    n_ddos_total= 6 * 8 * 60              -->  2,880 DDoS events
                                              ------
                                              5,760 burst events  *

(* This exactly reproduces the "+5,760 synthetic DoS/DDoS bursts" figure
   referenced in Section 4.4 of the methodology.  Counts are reproducible
   to-the-byte across runs given the seed; see `count_burst_events()`
   below for the formal calculation that is checked at runtime.)

In addition to the 2 burst categories, in-place REPLACEMENTS produce:
    Injection    : 5% of N  =  4,880 requested; about 4,748 survive because
                   the later malformed replacement overwrites ~132 of the same
                   rows (the exact survivor count depends on the seed)
    Malformed    : 3% of N  =  2,928     (modifies existing rows in place)
    Backdoor     : 5% of N  =  4,880     (modifies existing rows in place)
    Scanning     : 5% of N  =  4,880     (modifies existing rows in place)

In-place replacements do NOT change the total event count; only the
DoS / DDoS bursts INCREASE the event count from 97,600 to 103,360.

THREAT MAPPING TO TON_IoT CATEGORIES  (Section 3.5)
=========================================================================
(1) MQTT Protocol-Layer Attacks  --  caught by deterministic rules
       TON_IoT 'Injection'  -> r1 (topic-prefix authorisation mismatch)
       TON_IoT 'DoS'        -> r2 (per-client rate threshold)
       TON_IoT 'DDoS'       -> r2 (distributed) + r1 (suspicious prefix)
       MQTT v5 conformance  -> r3 (malformed packets)

(2) Telemetry Tampering / Process Anomalies  --  caught only by OIF
       TON_IoT 'Backdoor'   -> persistent payload drift in (f1, f2, f3)
       TON_IoT 'Scanning'   -> erratic out-of-bounds payload deviations
"""

import random
import copy
import json
import time


# =========================================================================
# Attack-mix fractions (deterministic; choose so the totals above hold)
# =========================================================================
# Fractions are of N = number of input rows.  Injection / malformed / backdoor /
# scanning REPLACE existing rows; dos / ddos only determine how many bursts are
# INSERTED (see count_burst_events).  Fractions sum to 24 % of N.
# ---------------------------------------------------------------------
# GROUND TRUTH
# ---------------------------------------------------------------------
# Attack classes created by this injector.  Rows of the source CSV that carry
# label = 1 but were NOT turned into one of these classes (attack_type
# "tampering") are random native labels: the label is
# statistically independent of every sensor column (AUC ~ 0.50), so they are
# not detectable and are not counted as attacks under the default definition.
INJECTED_ATTACK_TYPES = ("injection", "dos", "ddos", "malformed",
                         "backdoor", "scanning")


def ground_truth_label(ev, mode="injected"):
    """Return the 0/1 evaluation label of one event.
    mode "injected" (default, matches the base paper): 1 only for events of an
    injected attack class.  mode "all": legacy behaviour, the CSV/injector
    `label` field (adds the native label-1 rows)."""
    if mode == "all":
        return int(ev.get("label", 0))
    return 1 if ev.get("attack_type") in INJECTED_ATTACK_TYPES else 0


DEFAULT_ATTACK_MIX = {
    # --- Class (1) MQTT Protocol-Layer Attacks ---
    "injection": 0.05,   # TON_IoT  Injection   -> r1
    "dos":       0.03,   # TON_IoT  DoS         -> r2  (BURST INSERTED)
    "ddos":      0.03,   # TON_IoT  DDoS        -> r2 + r1  (STORM INSERTED)
    "malformed": 0.03,   # MQTT v5 conformance  -> r3 (+ r1)
    # --- Class (2) Telemetry Tampering / Process Anomalies ---
    "backdoor":  0.05,   # TON_IoT  Backdoor    -> OIF
    "scanning":  0.05,   # TON_IoT  Scanning    -> OIF
}

# Burst geometry -- single source of truth for the 5,760 figure.
DOS_BURST_SIZE      = 80          # packets per DoS burst
DDOS_BOTNET_SIZE    = 8           # bots per DDoS storm
DDOS_PKTS_PER_BOT   = 60          # packets per bot
# => DDoS storm size = 8 * 60 = 480 packets


# =========================================================================
# count_burst_events  -- the FORMAL 5,760-event calculation
# -------------------------------------------------------------------------
# This function is the compile-time proof that the burst count is exactly
# what the paper reports.  It is invoked once before any random sampling
# and the result is printed alongside the injected stream.
# =========================================================================
def count_burst_events(n_rows: int, attack_mix: dict = None) -> dict:
    """Return a deterministic dictionary describing how many DoS / DDoS
    burst events will be inserted for a stream of length n_rows under the
    given attack_mix.  No RNG is consulted -- the result is a pure
    function of (n_rows, attack_mix)."""
    mix = attack_mix or DEFAULT_ATTACK_MIX
    # int() truncation: 3 % of 97,600 = 2,928 -> 36 bursts of 80 (2,880) and
    # 6 storms of 480 (2,880); the 48 remainder events are not inserted.
    n_dos  = int(n_rows * mix.get("dos",  0.0))
    n_ddos = int(n_rows * mix.get("ddos", 0.0))
    n_dos_bursts  = max(1, n_dos  // DOS_BURST_SIZE) if n_dos  > 0 else 0
    n_ddos_storms = max(1, n_ddos // (DDOS_BOTNET_SIZE * DDOS_PKTS_PER_BOT)) \
                    if n_ddos > 0 else 0
    dos_events  = n_dos_bursts  * DOS_BURST_SIZE
    ddos_events = n_ddos_storms * DDOS_BOTNET_SIZE * DDOS_PKTS_PER_BOT
    total       = dos_events + ddos_events
    return {
        "n_input_rows":   n_rows,
        "n_dos_bursts":   n_dos_bursts,
        "dos_events":     dos_events,        # 36 * 80   = 2,880
        "n_ddos_storms":  n_ddos_storms,
        "ddos_events":    ddos_events,       # 6  * 480  = 2,880
        "total_burst":    total,             # 2,880 + 2,880 = 5,760
        "final_count":    n_rows + total,    # 97,600 + 5,760 = 103,360
    }


# =========================================================================
# CLASS (1) -- MQTT PROTOCOL-LAYER ATTACKS
# =========================================================================

# (1a) Injection : unauthorized topic + attacker client_id
def make_injection(base_event: dict) -> dict:
    # Replaces identity and topic: detected by r1 through the "attacker_"
    # prefix and the "unauthorized/" topic (both hard-coded in caef.py).
    ev = copy.deepcopy(base_event)
    ev["client_id"] = f"attacker_{random.randint(1000, 9999)}"
    ev["topic"]     = "unauthorized/" + random.choice(
        ["control/override", "config/admin", "secret/keys", "fw/update"])
    ev["label"]       = 1
    ev["attack_type"] = "injection"
    return ev


# (1b) DoS : tight burst that overruns per-client rate limit (rule r2)
def make_dos_burst(base_event: dict, burst_size: int = DOS_BURST_SIZE) -> list[dict]:
    # One attacker id sends `burst_size` identical-header packets back to back,
    # which exceeds the per-client rate limit (r2) when replayed quickly, and
    # whose id starts with "flood_bot_" (r1).
    burst = []
    attacker_id = f"flood_bot_{random.randint(100, 999)}"
    for _ in range(burst_size):
        ev = copy.deepcopy(base_event)
        ev["client_id"]   = attacker_id
        ev["topic"]       = "scada/control/rtu1/telemetry"
        ev["label"]       = 1
        ev["attack_type"] = "dos"
        burst.append(ev)
    return burst


# (1c) DDoS : multi-source flood (rule r2 + rule r1 suspicious-prefix)
def make_ddos_storm(base_event: dict,
                    botnet_size: int = DDOS_BOTNET_SIZE,
                    pkts_per_bot: int = DDOS_PKTS_PER_BOT) -> list[dict]:
    # Several bots, each sending pkts_per_bot packets in sequence.
    storm = []
    botnet = [f"ddos_bot_{random.randint(1000, 9999)}"
              for _ in range(botnet_size)]
    for bot in botnet:
        for _ in range(pkts_per_bot):
            ev = copy.deepcopy(base_event)
            ev["client_id"]   = bot
            ev["topic"]       = "scada/control/rtu1/telemetry"
            ev["label"]       = 1
            ev["attack_type"] = "ddos"
            storm.append(ev)
    return storm


# (1d) Malformed : violates MQTT v5 keep_alive / remaining_length bounds
def make_malformed(base_event: dict) -> dict:
    # Out-of-range MQTT fields: keep_alive = -1 and/or remaining_length above
    # the 4-byte variable-length-integer maximum (268,435,455) -> rule r3.
    ev = copy.deepcopy(base_event)
    ev["client_id"] = f"malformed_bot_{random.randint(100, 999)}"
    choice = random.choice(["bad_keep_alive", "bad_remaining_length", "both"])
    if choice in ("bad_keep_alive", "both"):
        ev["keep_alive"] = -1
    if choice in ("bad_remaining_length", "both"):
        ev["remaining_length"] = 999_999_999
    ev["label"]       = 1
    ev["attack_type"] = "malformed"
    return ev


# =========================================================================
# CLASS (2) -- TELEMETRY TAMPERING / PROCESS ANOMALIES
# =========================================================================

# (2a) Backdoor : persistent payload drift (legitimate header)
def make_backdoor(base_event: dict) -> dict:
    # Header stays legitimate; temperature +40..80 and humidity +30..60 are
    # added to the ORIGINAL value (a large but plausible-looking drift).
    ev = copy.deepcopy(base_event)
    offset_primary   = random.uniform(40.0, 80.0)
    offset_secondary = random.uniform(30.0, 60.0)
    ev["numeric_primary"]   = ev["numeric_primary"]   + offset_primary
    ev["numeric_secondary"] = ev["numeric_secondary"] + offset_secondary
    ev["label"]       = 1
    ev["attack_type"] = "backdoor"
    return ev


# (2b) Scanning : erratic out-of-bounds payload probing (legitimate header)
def make_scanning(base_event: dict) -> dict:
    # Header stays legitimate; the three payload channels are replaced by
    # uniform random values in very wide ranges (out-of-bounds probing).
    ev = copy.deepcopy(base_event)
    ev["numeric_primary"]   = random.uniform(-200.0, 300.0)
    ev["numeric_secondary"] = random.uniform(-150.0, 250.0)
    ev["numeric_tertiary"]  = random.uniform(0.0,    99_999.0)
    ev["label"]       = 1
    ev["attack_type"] = "scanning"
    return ev


# =========================================================================
# inject_attacks  --  in-process injection (no broker required)
# =========================================================================
def inject_attacks(benign_events: list[dict],
                   attack_mix: dict = None,
                   seed: int = 42,
                   verbose: bool = True) -> list[dict]:
    if attack_mix is None:
        attack_mix = DEFAULT_ATTACK_MIX
    # Two generators: `rng` (local) chooses positions/templates, while the
    # global `random` module (seeded below) is used inside make_* helpers for
    # ids and offsets.  Same seed -> same stream.
    rng = random.Random(seed)
    random.seed(seed)

    # ----- 1. FORMAL pre-injection accounting (proves the 5,760 figure) -
    plan = count_burst_events(len(benign_events), attack_mix)
    if verbose:
        print(f"\n[inject] formal burst-count plan  (computed BEFORE any RNG draws):")
        print(f"            n_input_rows               : {plan['n_input_rows']:>7,}")
        print(f"            DoS  bursts  ({DOS_BURST_SIZE} pkts each)   : "
              f"{plan['n_dos_bursts']:>5}   -> {plan['dos_events']:>5,} events")
        print(f"            DDoS storms  ({DDOS_BOTNET_SIZE}*{DDOS_PKTS_PER_BOT} pkts each)  : "
              f"{plan['n_ddos_storms']:>5}   -> {plan['ddos_events']:>5,} events")
        print(f"            -------------------------------- -----    --------")
        print(f"            TOTAL burst events inserted: {plan['total_burst']:>7,}")
        print(f"            Final event count (input+burst): {plan['final_count']:>7,}")

    n_original = len(benign_events)
    out = list(benign_events)          # shallow copy: events replaced, not mutated
    n  = len(benign_events)

    n_inj  = int(n * attack_mix.get("injection", 0.0))
    n_malf = int(n * attack_mix.get("malformed", 0.0))
    n_back = int(n * attack_mix.get("backdoor",  0.0))
    n_scan = int(n * attack_mix.get("scanning",  0.0))

    # ----- 2. In-place REPLACEMENTS (no count change) ------------------
    # Rows are drawn independently for each class, so a row picked by
    # "malformed" after "injection" overwrites it (see module docstring).
    for idx in rng.sample(range(len(out)), min(n_inj, len(out))):
        out[idx] = make_injection(out[idx])
    for idx in rng.sample(range(len(out)), min(n_malf, len(out))):
        out[idx] = make_malformed(out[idx])

    # backdoor: preferably clustered on 8 randomly chosen "compromised" devices;
    # only rows still labelled normal/tampering are eligible.  If those 8 devices
    # have fewer eligible rows than requested, ANY eligible row is used instead.
    if n_back > 0:
        all_devices = list({ev["client_id"] for ev in out
                            if not any(ev["client_id"].startswith(p) for p in
                                ("attacker_", "flood_bot_", "ddos_bot_",
                                 "malformed_bot_"))})
        if all_devices:
            compromised = rng.sample(all_devices, k=min(8, len(all_devices)))
            eligible = [i for i, ev in enumerate(out)
                        if ev["client_id"] in compromised
                        and ev["attack_type"] in ("normal", "tampering")]
            if len(eligible) < n_back:
                eligible = [i for i, ev in enumerate(out)
                            if ev["attack_type"] in ("normal", "tampering")]
            for idx in rng.sample(eligible, min(n_back, len(eligible))):
                out[idx] = make_backdoor(out[idx])

    # scanning: any row still labelled normal/tampering (native label-1 rows
    # can therefore be relabelled as scanning or backdoor).
    eligible = [i for i, ev in enumerate(out)
                if ev["attack_type"] in ("normal", "tampering")]
    for idx in rng.sample(eligible, min(n_scan, len(eligible))):
        out[idx] = make_scanning(out[idx])

    # ----- 3. INSERTED BURSTS (the 5,760 events) -----------------------
    # Each burst is copied from a random template event and inserted as one
    # contiguous block at a random position.
    for _ in range(plan["n_dos_bursts"]):
        template = rng.choice(out)
        burst    = make_dos_burst(template, burst_size=DOS_BURST_SIZE)
        pos      = rng.randint(0, len(out))
        out[pos:pos] = burst
    for _ in range(plan["n_ddos_storms"]):
        template = rng.choice(out)
        storm    = make_ddos_storm(template,
                                   botnet_size=DDOS_BOTNET_SIZE,
                                   pkts_per_bot=DDOS_PKTS_PER_BOT)
        pos      = rng.randint(0, len(out))
        out[pos:pos] = storm

    # ----- 4. Light shuffle that PRESERVES burst contiguity ------------
    # N/20 random swaps among non-burst events only (bursts never move).
    for _ in range(len(out) // 20):
        i = rng.randint(0, len(out) - 1)
        j = rng.randint(0, len(out) - 1)
        if (out[i]["attack_type"] not in ("dos", "ddos") and
            out[j]["attack_type"] not in ("dos", "ddos")):
            out[i], out[j] = out[j], out[i]

    # ----- 5. POST-injection assertion: plan was honoured EXACTLY ------
    n_after = len(out)
    n_added = n_after - n_original
    assert n_added == plan["total_burst"], (
        f"BURST COUNT VIOLATION: planned {plan['total_burst']}, "
        f"got {n_added} -- the injection module is broken.")

    if verbose:
        counts = {}
        for ev in out:
            counts[ev["attack_type"]] = counts.get(ev["attack_type"], 0) + 1
        print("\n[inject] post-injection attack-type breakdown:")
        for k in ("injection", "dos", "ddos", "malformed",
                  "backdoor", "scanning", "tampering", "normal"):
            if k in counts:
                print(f"            {k:<12s} {counts[k]:>7,}")
        print(f"\n[inject] ASSERT  inserted == planned : "
              f"{n_added:,} == {plan['total_burst']:,}    OK")
        print(f"[inject] final event count           : {n_after:,}")
    return out


# =========================================================================
# broker_inject  --  Publish the stream to a live Eclipse Mosquitto broker
# -------------------------------------------------------------------------
# This is the path that validates the simulation pipeline end-to-end:
#
#     attack_injector.broker_inject(events, "tcp://localhost:1883")
#                            |
#                            v
#                +---------------------------+
#                | Eclipse Mosquitto broker  |
#                |   (MQTT v5.0 publish)     |
#                +---------------------------+
#                            |
#                            v   subscribed by edge node
#                +---------------------------+
#                | CAEF C1_StreamMonitor     |
#                |   ... C2 ... C7           |
#                +---------------------------+
#
# Uses paho-mqtt v5 (mqttv5 protocol).  If paho-mqtt is not installed,
# the function raises a clean ImportError instead of crashing.
# =========================================================================
def broker_inject(events: list[dict],
                  broker_url: str = "tcp://localhost:1883",
                  topic_base: str = "scada",
                  rate_per_sec: float = 5000.0,
                  qos: int = 1,
                  verbose: bool = True) -> dict:
    """Programmatically publish every event in `events` to a live MQTT
    broker (Eclipse Mosquitto by default).  Each event is converted to
    a JSON payload and published on its native topic, simulating the
    real SCADA publish stream.

    Returns a dict with the per-class published counts (for verification).
    """
    try:
        import paho.mqtt.client as mqtt
        import paho.mqtt.properties as mqtt_props
    except ImportError as e:
        raise ImportError(
            "broker_inject requires paho-mqtt v2+ (pip install paho-mqtt). "
            f"Original error: {e}")

    # Strip the "tcp://" scheme and split host:port
    # (Not used by the paper experiments - needs a running MQTT broker.)
    url = broker_url.replace("tcp://", "")
    if ":" in url:
        host, port_s = url.split(":", 1)
        port = int(port_s)
    else:
        host, port = url, 1883

    client = mqtt.Client(client_id="caef_attack_injector",
                         protocol=mqtt.MQTTv5)
    client.connect(host, port, keepalive=60)
    client.loop_start()
    if verbose:
        print(f"[broker_inject] connected to {host}:{port}  (MQTT v5)")
        print(f"[broker_inject] publishing {len(events):,} events at "
              f"{rate_per_sec:.0f} msg/s ...")

    period_s = 1.0 / rate_per_sec
    counts = {}
    t0 = time.time()
    for ev in events:
        payload = json.dumps(ev, default=str).encode("utf-8")
        topic   = ev.get("topic", f"{topic_base}/unknown/telemetry")
        client.publish(topic, payload=payload, qos=qos)
        atype = ev.get("attack_type", "normal")
        counts[atype] = counts.get(atype, 0) + 1
        if period_s > 0:
            time.sleep(period_s)
    wall = time.time() - t0
    client.loop_stop()
    client.disconnect()

    if verbose:
        print(f"[broker_inject] published {len(events):,} events in "
              f"{wall:.2f}s   ({len(events)/wall:,.0f} msg/s)")
        for k in ("injection", "dos", "ddos", "malformed",
                  "backdoor", "scanning", "tampering", "normal"):
            if k in counts:
                print(f"      {k:<12s}: {counts[k]:>7,}")
    return {"published": len(events), "duration_s": wall,
            "per_class": counts}
