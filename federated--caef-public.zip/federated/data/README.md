# data/

Two datasets are used.  Neither is redistributed with this repository.

## 1. TON_IoT-format telemetry (main experiments)
Place the eight device-type CSV files here (Train_Test_IoT_Fridge.csv, ...,
Train_Test_IoT_Weather.csv; 12,200 rows each).  The files used for the paper
contain the columns timestamp, device_id, device_type, temperature, humidity,
pressure, voltage, current, power, status and label, with uniform value
distributions and a label that is statistically independent of every sensor
column; describe their origin in the paper before calling them real TON_IoT
measurements.

## 2. KDD Cup 99 (independent validation)
Place `KDDCup99.csv` (10 % subset, 494,020 rows, 41 features + label) in
`data/kdd/`.  `kdd_loader.py` documents the column -> Eq. 1 mapping;
`run_kdd_validation.py` runs the experiments.  Exact duplicate rows are removed
(145,585 unique rows remain).  Source: UCI KDD Archive,
https://www.kaggle.com/datasets/ericzs/kddcup99

