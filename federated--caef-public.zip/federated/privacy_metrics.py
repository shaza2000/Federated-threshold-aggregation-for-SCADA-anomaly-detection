"""
privacy_metrics.py
====================
Two privacy metrics for the federated extension (Eq.8), each computed
from THIS system's own real values -- not simulated or assumed.

METRIC 1 -- Communication Cost Reduction
-----------------------------------------
Source : Labate, D., Thakur, D., & Fortino, G. (2026). "Towards Secure
and Scalable Energy Theft Detection: A Federated Learning Approach for
Resource-Constrained Smart Meters." arXiv:2602.16181, Section
"F. Communication Cost and Bandwidth Reduction".

    Cost_FL          = 2 * R * K * P * B
    Cost_centralized = sum_{k=1}^{K} |D^(k)| * d * B

Applied here EXACTLY as defined in the source (no structural adaptation
needed -- unlike Eq.8, this formula is dimension-agnostic and applies
identically whether P is a full model-parameter vector or, as in our
case, a single scalar):
    K              = number of edge sites            (= 8)
    R              = number of Eq.8a rounds actually fired this run
    P              = parameters transmitted per site per round (= 1,
                     theta_local_s -- a single scalar, vs. thousands to
                     millions for a neural-network FL client)
    B              = bytes per parameter (4, IEEE-754 float32)
    |D^(k)|        = number of events site k processed this run
    d              = raw attribute count per event that centralization
                     would require transmitting (n=10, Eq.1's header+
                     payload attribute count -- NOT the 16-attribute
                     enriched event of Eq.2, since enrichment happens
                     locally and never needs to leave the site even in
                     the centralized baseline)

METRIC 2 -- Mutual Information Leakage
----------------------------------------
Source : Liu, Y., Zhu, X., Wang, J., & Xiao, J. (2021). "A Quantitative
Metric for Privacy Leakage in Federated Learning." arXiv:2102.13472,
Section 2.2.

    I(X_B; G^t) = D_KL[P_{X_B,G^t} || P_{X_B} x P_{G^t}]
                >= sup_{T in T} E_{P_{X_B,G^t}}[T] - log(E_{P_{X_B} x P_{G^t}}[e^T])
                                                        (Donsker-Varadhan bound)

NOTE: the value actually computed below is a k-NN (KSG) ESTIMATE, not this
lower bound, and it is the sum of eight one-dimensional estimates.

DISCLOSED ADAPTATION (see also the citation note on Eq.8):
The source paper estimates this bound with H-MINE, a neural statistic
network T_phi, because their G^t is a full gradient vector with
hundreds+ dimensions. Our G^t (theta_local_s) is a SINGLE SCALAR per
round -- training a neural estimator for a 1-D target is unjustified
machinery. We instead estimate the same quantity I(X_B; G^t) with a
k-NN-based non-parametric estimator (Kraskov/KSG-style, via sklearn's
mutual_info_regression), which is the standard, literature-supported
substitute for Donsker-Varadhan neural estimation in the low-dimensional
regime. We also report the paper's own baseline comparator, the summed
covariance C(X_B,G^t) = sum(cov(X_B,G^t)), exactly as defined in their
Section 3.1, for a second, estimator-independent sanity check.

    X_B  = per-round raw-window summary statistics at site s (mean/std
           of f1,f2,f3 and comp_vals over that round's local window --
           this is the site's actual raw telemetry signature; it NEVER
           leaves the site in the real system, exported here only so we
           can measure, after the fact, how much of it theta_local_s
           would reveal if it were the only thing an adversary saw)
    G^t  = theta_local_s (the one scalar that DOES leave the site)
"""

import numpy as np
from sklearn.feature_selection import mutual_info_regression


# ---------------------------------------------------------------------
# METRIC 1 : Communication cost reduction (Labate et al., 2026)
# ---------------------------------------------------------------------
def communication_cost_metric(K, R, per_site_event_counts, d=10, P=1, B_bytes=4):
    """Return Cost_FL, Cost_centralized and their ratio (all in bytes).

    K  : number of sites          R : number of federated rounds fired
    P  : parameters per site/round (1 scalar)   B_bytes : bytes per parameter
    d  : raw attributes per event a centralised design would upload (10)
    The deterministic result for the paper run is
        Cost_FL = 2*25*8*1*4 = 1,600 B,  Cost_centralized = 103,360*10*4 = 4,134,400 B.
    """
    D_k = list(per_site_event_counts.values())    # |D^(k)|: events per site
    N_total = sum(D_k)

    # Factor 2 = one upload (theta_local) + one download (theta_global)
    # per site per round.  K is the number of ALL sites, even though the
    # theta of a site only changes at its local refits (about 4 per site).
    Cost_FL = 2 * R * K * P * B_bytes
    # Centralised alternative: every raw event (d attributes, B bytes each)
    # is uploaded.  The injected attack bursts are included in |D^(k)|.
    Cost_centralized = sum(n * d * B_bytes for n in D_k)
    reduction_factor = (Cost_centralized / Cost_FL) if Cost_FL > 0 else float("inf")

    return {
        "symbols": {
            "K (sites)": K,
            "R (Eq.8a rounds fired)": R,
            "P (parameters/site/round)": P,
            "B (bytes/parameter, float32)": B_bytes,
            "d (raw attributes/event, Eq.1)": d,
            "N_total (events, all sites)": N_total,
            "|D^(k)| (events/site)": per_site_event_counts,
        },
        "Cost_FL_bytes": Cost_FL,
        "Cost_centralized_bytes": Cost_centralized,
        "reduction_factor": reduction_factor,
    }


# ---------------------------------------------------------------------
# METRIC 2 : Mutual-information leakage (adapted from Liu et al., 2021)
# ---------------------------------------------------------------------
def mutual_information_leakage_metric(mi_rows, seed=42):
    """Estimate I(X_B; G^t) between raw-window summaries and theta_local.

    mi_rows : list of dicts from FedC3_AnomalyDetectionEngine.
              export_privacy_metric_data() - one row per local refit.
    Headline value = rows built from full 4096-event windows only (when >= 8
    exist); the all-rows value and a permutation null are returned alongside.
    CAVEATS (read before quoting the number):
      * The reported value is a SUM of eight one-dimensional KSG estimates,
        not a joint multivariate mutual information; the sum can exceed the
        true joint value when the features are correlated.
      * scikit-learn clips negative estimates to 0, so independent variables
        give a positive value on average (finite-sample bias).  With n = 32
        that bias is about 0.3 nats (shuffle test).
      * Rows from the 64-sample first refit and from the 4096-sample later
        refits are mixed; window size alone makes both theta_local and the
        window std change, which inflates the estimate.
      * mutual_info_regression adds a tiny random jitter, hence random_state.
    """
    if len(mi_rows) < 8:
        return {"insufficient_samples": True, "n_samples": len(mi_rows)}

    # X_B: 8 summary statistics of the raw local window; G^t: the scalar sent.
    feat_cols = ["mean_f1", "std_f1", "mean_f2", "std_f2",
                "mean_f3", "std_f3", "mean_comp", "std_comp"]
    X_all = np.array([[row[c] for c in feat_cols] for row in mi_rows])
    y_all = np.array([row["theta_local_s"] for row in mi_rows])

    # WINDOW-SIZE CONFOUND: the first refit of every site uses a 64-event
    # window, later refits use 4096 events; window size alone changes both
    # theta and the window statistics.  The headline value therefore uses only
    # rows from full windows (n >= steady_window) when at least 8 exist.
    steady_window = 4096
    steady = [i for i, r in enumerate(mi_rows)
              if r.get("n", steady_window) >= steady_window]
    use_steady = len(steady) >= 8
    idx = steady if use_steady else list(range(len(mi_rows)))
    X, y = X_all[idx], y_all[idx]

    def _ksg_sum(Xm, ym):
        # Sum of per-feature KSG (k-NN) MI estimates, nats (sklearn).
        per = mutual_info_regression(
            Xm, ym, n_neighbors=min(3, len(ym) - 1), random_state=seed)
        return float(per.sum()), per

    # k-NN / KSG-style non-parametric MI estimator (sklearn), substituting
    # for the source paper's neural H-MINE estimator -- see module
    # docstring for why the substitution is appropriate here.
    n_neighbors = min(3, len(y) - 1)
    I_XB_Gt, mi_per_feature = _ksg_sum(X, y)
    I_all_rows, _ = _ksg_sum(X_all, y_all)

    # Permutation null: shuffle theta across rows (destroys any dependence) and
    # recompute the same statistic; compare the headline estimate with its
    # 95th percentile.
    rng = np.random.default_rng(seed)
    null = np.array([_ksg_sum(X, rng.permutation(y))[0] for _ in range(200)])

    # Paper's own baseline comparator (Section 3.1): summed covariance of
    # each feature column with theta_local (np.cov(...)[0,1] is cov(x_j, y)).
    C_XB_Gt = float(sum(
        np.cov(X[:, j], y)[0, 1] for j in range(X.shape[1])
    ))

    return {
        "symbols": {
            "X_B (features)": feat_cols,
            "G^t (target)": "theta_local_s",
            "n_samples (site-round pairs used)": len(y),
            "n_neighbors (KSG k)": n_neighbors,
        },
        "I_XB_Gt_nats": I_XB_Gt,
        "I_all_rows_nats": I_all_rows,
        "n_rows_all": len(mi_rows),
        "n_rows_used": len(y),
        "used_steady_state_windows_only": use_steady,
        "permutation_null_mean_nats": float(null.mean()),
        "permutation_null_p95_nats": float(np.percentile(null, 95)),
        "estimator": "sum of 8 one-dimensional KSG (k-NN) estimates; not a Donsker-Varadhan bound",
        "mi_per_feature_nats": dict(zip(feat_cols, mi_per_feature.tolist())),
        "C_XB_Gt_covariance_baseline": C_XB_Gt,
        "insufficient_samples": False,
    }


# Print the communication-cost metric.
def print_communication_cost_report(res):
    print("-" * 78)
    print(" METRIC 1 : Communication Cost Reduction")
    print(" Source: Labate, Thakur & Fortino (2026), arXiv:2602.16181, Sec. F")
    print("-" * 78)
    print("  Cost_FL          = 2 * R * K * P * B")
    print("  Cost_centralized = sum_k |D^(k)| * d * B")
    print()
    for k, v in res["symbols"].items():
        if k == "|D^(k)| (events/site)":
            print(f"  {k:32s}:")
            for sid, n in v.items():
                print(f"      {sid:16s}: {n:,}")
        else:
            print(f"  {k:32s}: {v}")
    print()
    print(f"  Cost_FL           = {res['Cost_FL_bytes']:,} bytes")
    print(f"  Cost_centralized  = {res['Cost_centralized_bytes']:,} bytes "
          f"({res['Cost_centralized_bytes']/1e6:.3f} MB)")
    print(f"  reduction factor  = {res['reduction_factor']:,.1f}x")
    print("-" * 78)


# Print the mutual-information estimate, its permutation null and the per-feature terms.
def print_mi_leakage_report(res):
    print("-" * 78)
    print(" METRIC 2 : Mutual-Information Leakage")
    print(" Source: Liu, Zhu, Wang & Xiao (2021), arXiv:2102.13472, Sec. 2.2")
    print(" (adapted: KSG k-NN estimator in place of H-MINE -- see module docstring)")
    print("-" * 78)
    if res.get("insufficient_samples"):
        print(f"  Only {res['n_samples']} site-round samples available "
              f"(need >= 8) -- run more events / rounds to compute this metric.")
        print("-" * 78)
        return
    print("  I(X_B; G^t) estimated with a k-NN (KSG) estimator -- an ESTIMATE, not the")
    print("  Donsker-Varadhan lower bound of the source paper; sum of 8 one-dimensional terms.")
    print()
    for k, v in res["symbols"].items():
        print(f"  {k:32s}: {v}")
    print()
    print(f"  I(X_B; theta_local_s)  = {res['I_XB_Gt_nats']:.6f} nats"
          f"   (rows used: {res['n_rows_used']} of {res['n_rows_all']}; "
          f"full windows only: {res['used_steady_state_windows_only']})")
    print(f"  same estimator on ALL rows (mixes 64- and 4096-event windows) = "
          f"{res['I_all_rows_nats']:.6f} nats")
    print(f"  permutation null (theta shuffled): mean = "
          f"{res['permutation_null_mean_nats']:.3f}, 95th pct = "
          f"{res['permutation_null_p95_nats']:.3f} nats")
    for feat, mi in res["mi_per_feature_nats"].items():
        print(f"      MI({feat:10s}; theta_local_s) = {mi:.6f} nats")
    print(f"  C(X_B, theta_local_s)  = {res['C_XB_Gt_covariance_baseline']:.6f} "
          f"(paper's covariance-sum baseline)")
    print("-" * 78)
