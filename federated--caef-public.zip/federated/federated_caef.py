"""
federated_caef.py
==================
Implements Eq.8 (C3-Fed : Federated Threshold Aggregation Module), the
federated-learning extension of the CAEF framework:

    "Federated learning across edge agents: ... A federated update
    protocol is proposed, allowing the anomaly detection model to share
    statistical knowledge across nodes without transmitting raw
    telemetry."

EQUATION CONFORMANCE NOTE
-------------------------
CITATION ACCURACY (verified against the source PDF -- see corrected note
below; an earlier draft of this note mis-cited this as a numbered
"Eq. X" of the source paper, which is incorrect):

    McMahan et al. (2017) contains exactly ONE numbered equation,
    Eq.(1): f(w) = (1/n) * sum_i f_i(w)  -- the global objective
    (a plain average loss over all n examples, no client weighting
    yet). The client-weighted DECOMPOSITION of that same objective,
    f(w) = sum_k (n_k/n) * F_k(w), appears in the prose immediately
    after Eq.(1) and is NOT itself separately numbered. The actual
    weighted-AGGREGATION step (averaging values FROM clients, which
    is what Eq.8a below is structurally modelled on) appears only
    inside "Algorithm 1: FederatedAveraging" (pseudocode, also not a
    numbered equation): w_(t+1) <- sum_{k=1}^{K} (n_k/n) * w_k^(t+1).

    Correct attribution used here:
    Eq.8a is adapted from the client-weighted aggregation step of the
    FederatedAveraging (FedAvg) algorithm, McMahan, H.B., Moore, E.,
    Ramage, D., Hampson, S., & Aguera y Arcas, B. (2017).
    "Communication-Efficient Learning of Deep Networks from
    Decentralized Data." Proceedings of the 20th International
    Conference on Artificial Intelligence and Statistics (AISTATS),
    PMLR 54:1273-1282 -- specifically Algorithm 1's aggregation line
    -- whose n_k/n weighting scheme itself follows the client-weighted
    objective decomposition introduced immediately after their Eq.(1).
    There, w_k is a full model-parameter vector produced by several
    rounds of local SGD (ClientUpdate); here theta_local_s is a single
    scalar produced by a local, gradient-free Isolation Forest
    calibration (no client sampling fraction C, no local epochs E, no
    minibatch B -- none of the SGD machinery of Algorithm 1 applies).

EQUATION NUMBERING (matches the federated-extension paper)
----------------------------------------------------------
    (8a)  theta_global^(r) = sum_s (n_s^(r) / N^(r)) * theta_local_s^(r)
    (8b)  shift_s^(r)      = lambda * ( theta_global^(r) - theta_local_s^(r) )
    (8c)  OIF_score(E_i, S_s) = Phi_s( comp_i - shift_s^(r) )
The long-form notes below were written when (8b) and (8c) were a single
equation called "Eq.8b"; in the code, `recentring_shift` is (8b) and
`phi_s_score` is (8c).  `lambda` is the argument `fed_lambda` (default 1.0).

Eq.8  C3-Fed :
    Eq.8a  theta_global^(r) = sum_s  (n_s^(r) / N^(r)) * theta_local_s^(r)
                              [adapted from the aggregation line of
                               Algorithm 1 (FederatedAveraging) in
                               McMahan et al. (2017) -- see citation
                               note above; there applied to full
                               model-weight vectors w_k, here applied
                               to a single scalar per site, theta_local_s]

    Eq.8b  OIF_score(E_i, S_s) = Phi_s( comp_i - (theta_global^(r) - theta_local_s^(r)) )
                              [CAEF-specific extension, NOT part of the
                               original FedAvg paper -- introduced here
                               because IsolationForest is non-parametric
                               and its per-tree structure cannot be
                               averaged the way neural-network weights
                               can; Eq.8b instead re-centres each site's
                               local calibration curve Phi_s toward the
                               federated threshold theta_global]

SYMBOLS (mirrors CONFIG/Table-3 style of caef.py)
--------------------------------------------------
    S                 : number of edge sites (= 8, one per TON_IoT
                        device_type: fridge, gps_tracker, garage_door,
                        light, modbus, motion_light, thermostat, weather)
    r                 : federated round index (one round every
                        CONFIG["window_size"] events, same cadence as
                        the Eq.3 OIF refit period)
    theta_local_s^(r) : local decision threshold of site s at round r
                        (the comp-value at which site s's local
                        calibration curve Phi_s crosses 0.5)
    n_s^(r)           : CUMULATIVE number of events site s has processed
                        up to round r (st.n_s is never reset), used as the
                        FedAvg weight.  (Earlier text said "since the
                        previous round"; the code counts from the start.)
    N^(r)             : sum_s n_s^(r)  (total events across all
                        reporting sites this round)
    theta_global^(r)  : federated (globally shared) threshold, Eq.8a
    comp_i            : deviation magnitude of event i, comp_i =
                        0.5*(|f1_i| + |f2_i|)   -- SAME definition as
                        used inside Eq.3 of caef.py, not a new symbol
    Phi_s(.)          : site s's local calibration curve (np.interp
                        lookup against the site's own IsolationForest
                        decision_function, identical construction to
                        C3_AnomalyDetectionEngine._oif_score, just
                        scoped per site instead of globally)

DESIGN
------
Baseline (caef.py, C3_AnomalyDetectionEngine):
    ONE global Online-Isolation-Forest instance is fit on a single
    pooled sliding window of (f1,f2,f3) vectors coming from ALL device
    types mixed together -- i.e. S = 1, no Eq.8 needed.

Federated variant (this file, FedC3_AnomalyDetectionEngine):
    S = 8 independent sites. Each site keeps its OWN local sliding
    window and fits its OWN local Isolation Forest -- no raw feature
    vector ever leaves a site. Every CONFIG["window_size"] events
    (one federated round r), every site that has a fitted model
    contributes only the single scalar theta_local_s^(r) (Eq.8a
    weighting). The resulting theta_global^(r) is broadcast back and
    used by every site to re-centre its own Phi_s (Eq.8b).

Everything else (C1, C2, C4, C5, C6, C7, and rules r1/r2/r3 inside C3)
is reused UNCHANGED from caef.py, so any measured difference in Table-2
metrics is attributable to Eq.8 alone.
"""

from collections import deque
import numpy as np
from sklearn.ensemble import IsolationForest

from caef import C3_AnomalyDetectionEngine, CONFIG


class _SiteState:
    """Per-site (per S_s) local state. Nothing in here is ever shared
    directly with another site -- only the derived scalar theta_local
    is exposed to the federated round (Eq.8a)."""
    # __slots__ keeps the per-site object small and prevents typos from
    # silently creating new attributes.
    __slots__ = ("window", "n_s", "iforest", "phi_z", "phi_score",
                 "theta_local", "theta_history", "window_summary_history")

    # Allocate the per-site buffers: local window, event counter, forest, calibration curve and histories.
    def __init__(self, window_size):
        self.window = deque(maxlen=window_size)   # local (f1,f2,f3) buffer
        self.n_s = 0                              # local event counter (FedAvg weight)
        self.iforest = None                       # local Isolation Forest
        self.phi_z = None                         # Phi_s x-axis (sorted comp values)
        self.phi_score = None                     # Phi_s y-axis (calibrated scores)
        self.theta_local = None                   # theta_local_s^(r)  (Eq.8a input)
        self.theta_history = deque(maxlen=50)      # last 50 theta_local values (one
                                                    # appended per LOCAL REFIT, not per
                                                    # federated round); used by the
                                                    # "variance" selective mode
        self.window_summary_history = deque(maxlen=50)
        # ^ per-round summary of the RAW local window (X_B in the MI-leakage
        #   metric, Liu et al. 2021): mean/std of f1,f2,f3 and comp_vals at
        #   the moment theta_local was computed. This never leaves the site
        #   -- it exists only so we, as evaluators, can measure how much
        #   information about it the single published scalar theta_local
        #   actually carries.


class FedC3_AnomalyDetectionEngine(C3_AnomalyDetectionEngine):
    """Drop-in replacement for C3_AnomalyDetectionEngine (Eq.3) that adds
    Eq.8 (C3-Fed): partitions the Online Isolation Forest per edge site
    and runs a federated threshold-averaging round every window_size
    events. r1/r2/r3 and the alpha-fusion of Eq.3 are inherited unchanged
    from the parent class.

    Two precision-protecting extensions, both OFF by default (fed_lambda=1.0,
    selective=False) so the original Eq.8 behaviour is reproduced exactly
    unless explicitly requested:

      * fed_lambda in [0,1] : damping factor on the Eq.8b re-centring shift.
            shift = fed_lambda * (theta_global - theta_local_s)
        fed_lambda=1.0 reproduces the original (full shift); fed_lambda=0.0
        disables federation entirely (each site keeps its own threshold).

      * selective=True, strong_factor : a site is treated as "strong" for
        the current round if its local sample count n_s this round is
        >= strong_factor * (average n_s across all reporting sites this
        round). Strong sites keep shift=0 (their own local threshold is
        NOT re-centred); only weaker/data-sparse sites are pulled toward
        theta_global. This targets the actual mechanism identified as the
        source of the recall gain (weak sites borrowing calibration from
        strong ones) without paying the precision cost on sites whose
        local threshold was already accurate.
    """

    # Configure the federated engine: site key, damping lambda (Eq.8b), selective mode and window size.
    def __init__(self, site_key="device_type", fed_lambda=1.0,
                 selective=False, strong_factor=1.0,
                 selective_mode="n_s", client_fraction=1.0, seed=42, **kwargs):
        # **kwargs (alpha, window_size, contamination) go to the parent C3.
        super().__init__(**kwargs)
        self.site_key = site_key         # event field that defines a "site"
        self.fed_lambda = fed_lambda
        self.selective = selective
        self.strong_factor = strong_factor
        self.selective_mode = selective_mode   # "n_s" or "variance"
        self.client_fraction = client_fraction # C in Algorithm 1: m=max(C*K,1)
        self._rng = np.random.RandomState(seed)   # only used when client_fraction < 1
        self._sites = {}                 # S_s -> _SiteState,  |sites| = S
        self._global_event_counter = 0   # drives round cadence r
        self.theta_global = None         # theta_global^(r), Eq.8a output
        self.fed_round = 0               # current round index r
        self._avg_n_s_this_round = None  # used when selective_mode="n_s"
        self._avg_var_this_round = None  # used when selective_mode="variance"
        self.last_round_participants = None  # sites sampled in the last round

    def _get_site(self, site_id) -> _SiteState:
        # Lazily create the local state the first time a site is seen.
        st = self._sites.get(site_id)
        if st is None:
            st = _SiteState(self.window_size)
            self._sites[site_id] = st
        return st

    # ---- local OIF score for site s, Phi_s(.)  (mirrors Eq.3's
    #      _oif_score, scoped to one site's own window/model) ----------
    def _phi_s(self, st: _SiteState, z_features, pairwise_max):
        # Phi_s : deviation magnitude -> anomaly score in [0,1] for ONE site.
        # Returns the final OIF score of this site, i.e. Eq. (8c) plus the
        # two local floors.  Steps: (1) update the site window, (2) cold
        # start / local refit, (3) apply the federated shift, (4) floors.
        st.window.append(z_features)
        st.n_s += 1

        # Cold-start path (identical floor to Eq.3, per site)
        if st.n_s < 64:
            comp_i = 0.5 * (abs(z_features[0]) + abs(z_features[1]))
            return float(np.clip(comp_i / 8.0, 0.0, 1.0))

        # Local refit of site s's own Isolation Forest (no cross-site data).
        # Happens at n_s = 64 (first fit, only 64 samples) and then at every
        # multiple of window_size LOCAL events (4096, 8192, 12288 ...), which
        # is independent of the GLOBAL round cadence used in
        # _maybe_run_federated_round.  Hence about 4 refits per site.
        if (st.iforest is None) or (st.n_s % self.window_size == 0):
            X = np.array(st.window)
            st.iforest = IsolationForest(
                n_estimators=CONFIG["iforest_trees"],
                contamination=self.contamination,
                max_samples=min(CONFIG["iforest_max_samples"], len(X)),
                random_state=42,
                n_jobs=1,
            )
            st.iforest.fit(X)
            df_batch = st.iforest.decision_function(X)
            df_threshold = float(np.quantile(df_batch, self.contamination))
            scores = 1.0 / (1.0 + np.exp(60.0 * (df_batch - df_threshold)))
            comp_vals = 0.5 * (np.abs(X[:, 0]) + np.abs(X[:, 1]))
            order = np.argsort(comp_vals)
            st.phi_z = comp_vals[order]        # sorted comp values (x-axis of Phi_s)
            st.phi_score = scores[order]       # matching scores   (y-axis of Phi_s)
            # theta_local_s^(r) : comp value where Phi_s crosses 0.5
            # (np.interp expects an increasing x-array; phi_score is only
            # approximately monotone, so the result is a numerical estimate).
            st.theta_local = float(np.interp(0.5, st.phi_score, st.phi_z))
            st.theta_history.append(st.theta_local)
            # Raw-window summary X_B, stored ONLY for the after-the-fact
            # mutual-information measurement (it is never transmitted).
            # Note the first entry of each site comes from a 64-sample
            # window and the others from 4096-sample windows.
            st.window_summary_history.append({
                "mean_f1": float(X[:, 0].mean()), "std_f1": float(X[:, 0].std()),
                "mean_f2": float(X[:, 1].mean()), "std_f2": float(X[:, 1].std()),
                "mean_f3": float(X[:, 2].mean()), "std_f3": float(X[:, 2].std()),
                "mean_comp": float(comp_vals.mean()), "std_comp": float(comp_vals.std()),
                "n": int(len(X)),
            })

        # comp_i = 0.5(|f1| + |f2|): deviation magnitude of THIS event.
        comp_i = 0.5 * (abs(z_features[0]) + abs(z_features[1]))

        # ---- Eq.8b : re-centre Phi_s toward theta_global^(r) --------
        #      with optional damping (fed_lambda) and optional selective
        #      federation (strong sites keep shift=0). Two strength tests
        #      are supported: "n_s" (more local samples = strong) and
        #      "variance" (lower round-to-round theta_local variance =
        #      more stable = strong; a low-sample site can still be
        #      "strong" here if its threshold happens to be consistent).
        if self.theta_global is not None and st.theta_local is not None:
            if not self.selective:
                is_strong = False
            elif self.selective_mode == "variance":
                if len(st.theta_history) >= 2 and self._avg_var_this_round is not None \
                        and self._avg_var_this_round > 0:
                    my_var = float(np.var(st.theta_history))
                    is_strong = my_var <= self.strong_factor * self._avg_var_this_round
                else:
                    is_strong = False   # not enough history yet -> treat as weak
            else:  # "n_s" (original heuristic)
                is_strong = (
                    self._avg_n_s_this_round is not None
                    and st.n_s >= self.strong_factor * self._avg_n_s_this_round
                )

            if is_strong:
                recentring_shift = 0.0
            else:
                # (8b): shift = lambda * (theta_global - theta_local_s).
                # A positive shift (global threshold above the local one) is
                # SUBTRACTED from comp_i below, so the event looks less
                # anomalous; a negative shift makes it look more anomalous.
                recentring_shift = self.fed_lambda * (self.theta_global - st.theta_local)
        else:
            recentring_shift = 0.0   # no federated round has run yet (r = 0)

        # (8c): evaluate the site's own calibration curve at the shifted
        # deviation.  np.interp clamps outside the table range, so very large
        # deviations return the highest stored score.
        phi_s_score = float(np.interp(comp_i - recentring_shift,
                                       st.phi_z, st.phi_score))

        # Same Stage-2 floors as Eq.3 (pairwise/deviation floors are
        # local-only by construction, not part of Eq.8)
        deviation_floor = float(np.clip((comp_i - 2.0) / 6.0, 0.0, 1.0))
        pairwise_floor  = float(np.clip((pairwise_max - 2.0) / 6.0, 0.0, 1.0))

        # Same max-of-three combination as the baseline _oif_score.
        return float(max(phi_s_score, deviation_floor, pairwise_floor))

    # ---- Eq.8a : federated round -- FedAvg over the scalar thetas ----
    def _maybe_run_federated_round(self):
        # Called once per event (all sites together).  A round fires every
        # window_size GLOBAL events: 103,360 events / 4096 -> R = 25 rounds.
        self._global_event_counter += 1
        if self._global_event_counter % self.window_size != 0:
            return
        eligible = [(sid, st) for sid, st in self._sites.items()
                    if st.theta_local is not None]
        if len(eligible) < 2:
            return   # need >=2 sites reporting to "federate" this round

        # Algorithm 1 (McMahan et al., 2017): S_t = random set of
        # m = max(C*K, 1) clients out of K. C=1.0 (default) reproduces
        # the original behaviour (every eligible site participates).
        K = len(eligible)
        m = max(int(round(self.client_fraction * K)), 1)
        if m < K:
            idx = self._rng.choice(K, size=m, replace=False)
            reporting = [eligible[i] for i in idx]
        else:
            reporting = eligible
        self.last_round_participants = [sid for sid, _ in reporting]

        # FedAvg inputs: weights n_s (cumulative event counts) and scalars theta_s.
        n_s   = np.array([st.n_s        for _, st in reporting], dtype=np.float64)
        theta_s = np.array([st.theta_local for _, st in reporting], dtype=np.float64)
        N = float(n_s.sum())     # N^(r) = sum of the weights

        # Eq.8a :  theta_global^(r) = sum_s (n_s/N) * theta_local_s
        #          (sum restricted to the sampled set S_t, per Algorithm 1)
        self.theta_global = float(np.sum((n_s / N) * theta_s))
        # Statistics used only by the optional "selective" modes (OFF by default).
        self._avg_n_s_this_round = float(n_s.mean())

        variances = [float(np.var(st.theta_history)) for _, st in reporting
                    if len(st.theta_history) >= 2]
        self._avg_var_this_round = float(np.mean(variances)) if variances else None

        self.fed_round += 1      # R, the number of completed rounds

    def export_privacy_metric_data(self):
        """Everything needed to compute the two privacy metrics, gathered
        from this instance's own per-site state -- nothing here was ever
        transmitted between sites; it is exported only for OUR OWN
        after-the-fact measurement of how much it would have leaked if it
        HAD been the thing shared (used as the X_B side of the MI-leakage
        metric, Liu et al. 2021)."""
        per_site_event_counts = {sid: st.n_s for sid, st in self._sites.items()}
        # NOTE: one row per LOCAL REFIT of each site (about 4 per site -> 32
        # rows for 8 sites), not one row per federated round (R = 25).
        mi_rows = []   # each row: (site_id, round_features..., theta_local)
        for sid, st in self._sites.items():
            for summary, theta in zip(st.window_summary_history, st.theta_history):
                mi_rows.append({"site": sid, **summary, "theta_local_s": theta})
        return {
            "K": len(self._sites),
            "R": self.fed_round,
            "per_site_event_counts": per_site_event_counts,
            "mi_rows": mi_rows,
        }

    def process(self, event: dict) -> dict:
        # Same contract as C3_AnomalyDetectionEngine.process: read f1..f6 from
        # the event, write oif_score / r_score / r1..r3 / a_i back, plus a few
        # extra federated fields (site id, theta_local, theta_global, round).
        site_id = event.get(self.site_key, "unknown_site")
        st = self._get_site(site_id)

        z_feats = (
            event["f1_temperature_zscore"],
            event["f2_humidity_zscore"],
            event["f3_pressure_zscore"],
        )
        pairwise_max = max(
            event["f4_temp_vs_pressure_dev"],
            event["f5_temp_vs_humidity_dev"],
            event["f6_humidity_vs_pressure_dev"],
        )

        # Eq.8c/8b (per-event score) then Eq.8a (per-round aggregation).
        # The round check runs AFTER scoring, so the event that closes a round
        # is still scored with the previous theta_global.
        oif = self._phi_s(st, z_feats, pairwise_max)
        self._maybe_run_federated_round()

        # Eq.3 rules + fusion, inherited verbatim from the parent class
        r1 = self._rule_r1(event.get("client_id"), event.get("topic"))
        r2 = self._rule_r2(event.get("client_id"))
        r3 = self._rule_r3(event)
        r_score = self.w[0] * r1 + self.w[1] * r2 + self.w[2] * r3
        a_i = self.alpha * oif + (1.0 - self.alpha) * r_score

        event["oif_score"]   = oif
        event["r_score"]     = r_score
        event["r1"], event["r2"], event["r3"] = r1, r2, r3
        event["a_i"]         = float(a_i)
        event["_site_id"]    = site_id
        event["theta_local_s"]  = st.theta_local
        event["theta_global_r"] = self.theta_global
        event["fed_round"]      = self.fed_round
        return event
