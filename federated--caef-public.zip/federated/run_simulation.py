"""
run_simulation.py
=================
Drives the CAEF pipeline against TON_IoT data and prints:

    1. The schema mapping (paper Eq.1 symbols  <->  TON_IoT CSV columns)
    2. The active CONFIG (weights / thresholds from Section 3.6)
    3. A per-event trace through C1..C7 with the equation evaluated at
       each step, following the methodology of the CAEF framework.
    4. The final Table-2 evaluation block:
         - End-to-End Capture Latency  L_E2E   (Eq. 9)
         - Volatile Artifact Preservation Rate  PR
         - Trigger Precision  P_trigger

    5. (Federated extension) the same stream through FedC3, followed by the
       communication-cost and mutual-information privacy metrics.

THIS IS THE SCRIPT THAT PRODUCES THE NUMBERS OF THE FEDERATED PAPER
(PR, P_trigger, latency, R, Cost_FL, Cost_centralized, MI).  Run order:
    load CSVs -> interleave the 8 sites round-robin -> inject attacks ->
    per-event trace demo (separate FedC3 instance, not used for metrics) ->
    BASELINE pass (CAEFPipeline) -> FEDERATED pass (FedC3) -> metrics.
Both passes use the SAME event list; only C3 differs.

Reproducibility: the attack placement is seeded (--seed), but rule r2 uses the
wall clock, so PR and precision vary by a fraction of a percentage point with
machine speed and between repeated runs.  Only R, the byte counts and the
mutual-information value (for a given seed) are deterministic.  There is no
multi-seed driver in this archive; loop over --seed 42..51 to average.

Usage:
    python run_simulation.py                          # synthetic
    python run_simulation.py --csv data/              # TON_IoT-style
    python run_simulation.py --csv data/  --max-rows 5000
"""

import os
import sys
import time
import argparse
import json
from pathlib import Path

from caef import (
    CAEFPipeline,
    C1_StreamMonitor, C2_FeatureEnrichment,
    C3_AnomalyDetectionEngine, C4_ContextAnalysisModule,
    C5_TriggerDecisionUnit, C6_EvidenceAcquisition, C7_ProvenanceSealing,
    CONFIG,
)
from federated_caef import FedC3_AnomalyDetectionEngine
from privacy_metrics import (communication_cost_metric, print_communication_cost_report,
                              mutual_information_leakage_metric, print_mi_leakage_report)
from ton_iot_loader import load_ton_iot, make_ton_iot_synthetic
from attack_injector import inject_attacks, DEFAULT_ATTACK_MIX, ground_truth_label
from evaluation import print_report
from collections import defaultdict


def interleave_by_site(events, site_key="device_type"):
    # (Interleaving is applied BEFORE attack injection in main().)
    """Round-robin merge across sites -- emulates concurrent MQTT
    publishers on the same broker (Section 3.6.2), not a sequential
    per-file CSV read (the raw loader reads one device_type's CSV fully
    before the next, which does not reflect a live broker stream)."""
    # Group events by site, then repeatedly take one event from each site's
    # queue in turn (site order = first appearance in the input).
    buckets = defaultdict(list)
    for ev in events:
        buckets[ev.get(site_key, "unknown")].append(ev)
    queues = list(buckets.values())
    out, idxs = [], [0] * len(queues)
    remaining = sum(len(q) for q in queues)
    while remaining > 0:
        for qi, q in enumerate(queues):
            if idxs[qi] < len(q):
                out.append(q[idxs[qi]])
                idxs[qi] += 1
                remaining -= 1
    return out


BAR = "=" * 78     # width of the console banners


def banner(title: str):
    # Print a title between two separator lines (console formatting only).
    print()
    print(BAR)
    print(f" {title}")
    print(BAR)


# =========================================================================
# Per-component event trace -- one event PER attack class, printing the
# equation evaluated at every step (Eq.1 .. Eq.7).
# =========================================================================
def _print_event_trace(idx: int, ev_in: dict,
                       c1, c2, c3, c4, c5, c6, c7) -> None:
    # Pretty-prints ONE event through every component so a reader can follow
    # each equation with real numbers.  Purely informational: it mutates the
    # pipeline objects it is given (C2/C3 statistics advance) but its results
    # are not used for the reported metrics.

    print()
    print("-" * 78)
    print(f"  EVENT #{idx}      attack_type = '{ev_in['attack_type']}'    "
          f"ground_truth label = {ev_in['label']}")
    print("-" * 78)

    # ---------- RAW EVENT  (Eq.1 attribute groups) ----------
    print("  A_i^(header)   (|.| = 4   per paper Eq.1)")
    print(f"      topic_i           = {ev_in['topic']}")
    print(f"      client_id_i       = {ev_in['client_id']}")
    print(f"      QoS_i             = {ev_in['QoS']}")
    print(f"      t_i^broker        = {ev_in['broker_ts']}")
    print( "      [aux MQTT v5 protocol fields for r3]:")
    print(f"      keep_alive        = {ev_in['keep_alive']}")
    print(f"      remaining_length  = {ev_in['remaining_length']}")
    print()
    print("  A_i^(payload)  (|.| = 6   per paper Eq.1)")
    print(f"      M_i^num.primary    <- temperature ch.  : {ev_in['numeric_primary']:10.3f}")
    print(f"      M_i^num.secondary  <- humidity    ch.  : {ev_in['numeric_secondary']:10.3f}")
    print(f"      M_i^num.tertiary   <- pressure    ch.  : {ev_in['numeric_tertiary']:10.3f}")
    print(f"      M_i^num.voltage                        : {ev_in.get('numeric_electrical_v', 0):10.3f}")
    print(f"      M_i^num.current                        : {ev_in.get('numeric_electrical_i', 0):10.3f}")
    print(f"      M_i^num.power                          : {ev_in.get('numeric_electrical_p', 0):10.3f}")
    print(f"      S_i^cat            = status            : {ev_in['status']}")
    print(f"      L_i^(loc)          = location          : {ev_in['location']}")
    print(f"      type_i             = device_type       : {ev_in['device_type']}")
    print(f"      t_i^device                             : {ev_in['device_ts']}")
    print(f"      device_id_i                            : {ev_in['device_id']}")

    # ---------- C1 Interception (Eq.1) ----------
    e1 = c1.process(dict(ev_in), source_id="edge_node_01")
    print()
    print("  >> C1  Eq.1   M_stream(S_j, dt) = E_i^MQTT  U  {m_k}_{k=1..4}")
    print("     forensic metadata appended at the edge :")
    print(f"      m_1 _edge_ts       : {e1['_edge_ts']}  (ns UTC)")
    print(f"      m_2 _source_id     : {e1['_source_id']}")
    print(f"      m_3 _stream_seq    : {e1['_stream_seq']}")
    print(f"      m_4 _volatile_flag : {e1['_volatile_flag']}")

    # ---------- C2 Enrichment (Eq.2) ----------
    e2 = c2.process(e1)
    print()
    print("  >> C2  Eq.2   F_E(E_i) = E( N(E_i), C^(m), S_E ) = N_i^(n+m, Gamma)")
    print("     Stage 1 -- univariate z-scores  f_k = (x_k - mu_k) / sigma_k :")
    print(f"      f1 = z(temperature)   = {e2['f1_temperature_zscore']:+.3f}")
    print(f"      f2 = z(humidity)      = {e2['f2_humidity_zscore']:+.3f}")
    print(f"      f3 = z(pressure)      = {e2['f3_pressure_zscore']:+.3f}")
    print("     Stage 2 -- pairwise deviations  |f_i - f_j| :")
    print(f"      f4 = |f1 - f3|        = {e2['f4_temp_vs_pressure_dev']:.3f}     (temp vs pressure)")
    print(f"      f5 = |f1 - f2|        = {e2['f5_temp_vs_humidity_dev']:.3f}     (temp vs humidity)")
    print(f"      f6 = |f2 - f3|        = {e2['f6_humidity_vs_pressure_dev']:.3f}     (humid vs pressure)")
    print(f"     => n + m = 10 + 6 = 16 attributes total")

    # ---------- C3 Anomaly (Eq.3) ----------
    e3 = c3.process(e2)
    print()
    print("  >> C3  Eq.3   a_i = alpha * OIF(f1,f2,f3) + (1-alpha) * R_MQTT(E_i)")
    print(f"      OIF_score (Isolation Forest on f1,f2,f3) : {e3['oif_score']:.3f}")
    print(f"      r1  (topic-auth)            : {e3['r1']:.1f}"
          + ("   <-- VIOLATION" if e3['r1'] >= 0.5 else ""))
    print(f"      r2  (rate-limit per client) : {e3['r2']:.1f}"
          + ("   <-- VIOLATION" if e3['r2'] >= 0.5 else ""))
    print(f"      r3  (MQTT v5 conformance)   : {e3['r3']:.1f}"
          + ("   <-- VIOLATION" if e3['r3'] >= 0.5 else ""))
    w = CONFIG['rule_weights']
    print(f"      R_MQTT = w1*r1 + w2*r2 + w3*r3 "
          f"= {w[0]}*{e3['r1']:.1f} + {w[1]}*{e3['r2']:.1f} + {w[2]}*{e3['r3']:.1f}"
          f" = {e3['r_score']:.3f}")
    print(f"      => a_i = {CONFIG['alpha']}*{e3['oif_score']:.3f}"
          f" + {1-CONFIG['alpha']}*{e3['r_score']:.3f}"
          f" = {e3['a_i']:.3f}")

    # ---------- Eq.8 : C3-Fed (federated threshold aggregation) --------
    # Only printed if c3 is a FedC3_AnomalyDetectionEngine instance (i.e.
    # demonstrate_components was called with the federated C3); a plain
    # C3_AnomalyDetectionEngine has no theta_local_s/theta_global_r/fed_round
    # fields, so this block is skipped for the original baseline C3.
    if "theta_local_s" in e3:
        print()
        print("  >> C3-Fed  Eq.8   theta_global^(r) = sum_s (n_s/N) * theta_local_s")
        print("                    Phi_s(comp_i - (theta_global^(r) - theta_local_s^(r)))")
        tl = f"{e3['theta_local_s']:.3f}" if e3['theta_local_s'] is not None else "n/a (cold-start)"
        tg = f"{e3['theta_global_r']:.3f}" if e3['theta_global_r'] is not None else "n/a (round 0 not yet fired)"
        print(f"      site (S_s)          : {e3['_site_id']}")
        print(f"      theta_local_s^(r)   : {tl}")
        print(f"      theta_global^(r)    : {tg}   (fed_round r = {e3['fed_round']})")

    # ---------- C4 Context (Eq.4) ----------
    e4 = c4.process(e3)
    print()
    print("  >> C4  Eq.4   c_i = beta1 * crit_i + beta2 * zone_i")
    print(f"      crit_i  (NIST SP 800-30)      : {e4['crit_i']:.1f}")
    print(f"      zone_i  (IEC 62443-3-3)       : {e4['zone_i']:.1f}")
    print(f"      => c_i = {CONFIG['beta1']}*{e4['crit_i']:.1f}"
          f" + {CONFIG['beta2']}*{e4['zone_i']:.1f}"
          f" = {e4['c_i']:.3f}")

    # ---------- C5 Trigger (Eq.5) ----------
    e5 = c5.process(e4)
    a_ok = e5['a_i'] >= CONFIG['theta_anomaly']
    c_ok = e5['c_i'] >= CONFIG['theta_context']
    print()
    print("  >> C5  Eq.5   d_i = 1  iff  (a_i >= theta_a)  AND  (c_i >= theta_c)")
    print(f"      a_i ({e5['a_i']:.3f}) >= theta_a ({CONFIG['theta_anomaly']:.2f}) ? "
          f"{'YES' if a_ok else 'no '}")
    print(f"      c_i ({e5['c_i']:.3f}) >= theta_c ({CONFIG['theta_context']:.2f}) ? "
          f"{'YES' if c_ok else 'no '}")
    if e5['d_i'] == 1:
        print(f"      => d_i = 1     ** TRIGGER -- proceed to Phase 3 **")
    else:
        print(f"      => d_i = 0     (event discarded, EA_i = empty)")

    # ---------- Phase 3 (Eq.6, Eq.7) -- ALWAYS printed, 1..8 in order ----
    #      Eq.6 itself is defined (EA_i = N_i U {...} if d_i=1 else empty)
    #      so "EA_i = empty" IS the correct Eq.6 output when d_i=0, not a
    #      skipped step -- printed explicitly instead of omitting the lines.
    if e5['d_i'] == 1:
        ea     = c6.process(e5)
        sealed = c7.process(ea)
        print()
        print("  >> C6  Eq.6   EA_i = N_i U {a_i, c_i, t_i^capture}   [d_i=1 -> populated]")
        print(f"      a_i               = {ea['a_i']:.3f}")
        print(f"      c_i               = {ea['c_i']:.3f}")
        print(f"      t_i^capture       = {ea['t_capture']}")
        print()
        print("  >> C7  Eq.7   EA_sealed = EA_i U {h_i, t_i^stamp, M_i, P_i}   [d_i=1 -> sealed]")
        print(f"      h_i  (SHA-256)    = {sealed['h_i']}")
        print(f"      t_i^stamp         = RFC 3161  digest="
              f"{sealed['t_stamp']['hash_digest'][:16]}...")
        print(f"      M_i  (ISO 27037)  = collector={sealed['M_i']['collector']}"
              f"  role={sealed['M_i']['role']}")
        print(f"      P_i  (chain)      = prev_hash={sealed['P_i']['prev_hash'][:16]}..."
              f"  link_seq={sealed['P_i']['link_seq']}")
    else:
        print()
        print("  >> C6  Eq.6   EA_i = N_i U {a_i,c_i,t_capture} if d_i=1 else empty-set")
        print(f"      d_i=0  =>  EA_i = \u2205   (empty set, per Eq.6's own definition)")
        print("  >> C7  Eq.7   EA_sealed = EA_i U {h_i,t_stamp,M_i,P_i}")
        print(f"      d_i=0  =>  EA_sealed = \u2205   (nothing to seal, C7 not invoked)")


def demonstrate_components(sample_events: list[dict],
                           device_registry: dict) -> None:
    """Trace one event per attack class through C1..C7, plus Eq.8 (C3-Fed).
    Uses its own fresh components, so it does not influence the metric runs."""
    print()
    print("#" * 78)
    print("#  PER-COMPONENT EVENT TRACING  --  paper Eq.1 .. Eq.8 executed live")
    print("#" * 78)

    c1 = C1_StreamMonitor()
    c2 = C2_FeatureEnrichment()
    c3 = FedC3_AnomalyDetectionEngine(site_key="device_type")
    c4 = C4_ContextAnalysisModule(device_registry=device_registry)
    c5 = C5_TriggerDecisionUnit()
    c6 = C6_EvidenceAcquisition()
    c7 = C7_ProvenanceSealing()

    # Warm-up on the REAL, unfiltered stream (not just "normal" events),
    # and long enough (>= window_size) that at least one Eq.8a federated
    # round has fired before we print -- otherwise theta_global_r would
    # show as n/a for every traced event.
    n_warm = max(5000, CONFIG["window_size"] + 500)   # = 5000 events
    warm = sample_events[:n_warm]
    for ev in warm:
        x = c1.process(dict(ev), source_id="edge_node_01")
        x = c2.process(x)
        c3.process(x)
    print(f"\n  [warm-up] {n_warm:,} events processed first -- "
          f"Eq.8a has fired {c3.fed_round} round(s) "
          f"(theta_global = {c3.theta_global})")

    # Find one event per attack class
    classes = ["normal",
               "injection", "dos", "ddos", "malformed",
               "backdoor", "scanning", "tampering"]
    picks = []
    for cls in classes:
        ev = next((e for e in sample_events[n_warm:]
                   if e["attack_type"] == cls), None)
        if ev is not None:
            picks.append(ev)

    banner("PHASE 1, 2, 3   --  one trace per attack class")
    for i, ev in enumerate(picks, 1):
        _print_event_trace(i, ev, c1, c2, c3, c4, c5, c6, c7)
    print()


def main():
    # Command-line options: --csv (file or directory), --max-rows (truncate),
    # --seed (attack placement), --no-inject, --dump-evidence (unused here).
    parser = argparse.ArgumentParser(
        description="CAEF reference run on TON_IoT")
    parser.add_argument("--csv",      type=str, default=None,
                        help="TON_IoT CSV file OR directory of CSVs")
    parser.add_argument("--max-rows", type=int, default=None)
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--no-inject", action="store_true",
                        help="Skip attack injection (use only CSV labels)")
    parser.add_argument("--dump-evidence", type=str, default=None)
    parser.add_argument("--ground-truth", choices=["injected", "all"],
                        default="injected",
                        help="injected (default): attacks = injected classes "
                             "only; all: also count native label-1 rows")
    args = parser.parse_args()
    gt = args.ground_truth

    banner("CAEF  --  Context-Aware Autonomous Edge Forensics")
    print(" Implementation of Chapter 3 (C1..C7 + Phases 1/2/3)")
    print(" Equations Eq.1 .. Eq.7 executed in code, one per component")
    print(" Dataset : TON_IoT  (Alsaedi et al., 2020)")

    # ----- 1. Load events -----
    # With --csv the CSV files are read; without it (or if the path does not
    # exist) the synthetic generator is used instead.
    print("\n[1/4] Loading events ...")
    # Default: use data/ next to this script when it contains the CSV files.
    if args.csv is None:
        _d = Path(__file__).resolve().parent / "data"
        if _d.is_dir() and any(_d.glob("*.csv")):
            args.csv = str(_d)
    if args.csv and Path(args.csv).exists():
        events, device_registry = load_ton_iot(args.csv, max_rows=args.max_rows)
        source = "TON_IoT-style CSV"
    else:
        if args.csv:
            print(f"  [!] {args.csv} not found -- falling back to synthetic")
        events, device_registry = make_ton_iot_synthetic(
            n_per_device=(args.max_rows // 8) if args.max_rows else 12200,
            seed=args.seed)
        source = "synthetic TON_IoT-style stream"
        print("  [!] WARNING: no CSV files found - using the SYNTHETIC generator.")
        print("      Results will NOT match the paper.  Put the eight CSV files")
        print("      in data/ (see data/README.md) and run: python run_simulation.py --csv data/")
    n_ton_iot = len(events)        # rows before any burst is inserted (97,600)

    # ----- 1b. Print schema mapping (paper Eq.1 <-> TON_IoT) ----
    banner("Schema mapping  --  paper Eq.1 symbols  <->  TON_IoT columns")
    print(f"  Source : {source}")
    print()
    print("  +-----------------+-----------------+--------------------------+")
    print("  | Paper symbol    | Group           | Source                   |")
    print("  +-----------------+-----------------+--------------------------+")
    print("  | topic_i         | A_header        | synth from device_type   |")
    print("  | client_id_i     | A_header        | device_id column         |")
    print("  | QoS_i           | A_header        | MQTT v5 default = 1      |")
    print("  | t_i^broker      | A_header        | timestamp / ts column    |")
    print("  +-----------------+-----------------+--------------------------+")
    print("  | M_i^num         | A_payload       | (temp, humid, press,     |")
    print("  |   primary    -> f1  Eq.2          |  voltage, current, power)|")
    print("  |   secondary  -> f2                |                          |")
    print("  |   tertiary   -> f3                |                          |")
    print("  | S_i^cat         | A_payload       | status column            |")
    print("  | L_i^(loc)       | A_payload       | synthesised zone label   |")
    print("  | type_i          | A_payload       | device_type column       |")
    print("  | t_i^device      | A_payload       | ts column                |")
    print("  | device_id_i     | A_payload       | device_id column         |")
    print("  +-----------------+-----------------+--------------------------+")
    print("  | m_k (k=1..4)    | METADATA (Eq.1) | appended by C1 at intercept|")
    print("  +-----------------+-----------------+--------------------------+")
    print("  | label           | GROUND TRUTH    | label column (NOT seen   |")
    print("  | attack_type     | GROUND TRUTH    |  by C3/C4/C5)            |")
    print("  +-----------------+-----------------+--------------------------+")

    # ----- 1c. Print active CONFIG -----
    banner("Active hyperparameters  (Section 3.6 grid-search output)")
    print(f"  Eq.3  alpha                  = {CONFIG['alpha']:.2f}")
    rw = CONFIG['rule_weights']
    print(f"  Eq.3  rule weights (w1,w2,w3) = ({rw[0]:.2f}, {rw[1]:.2f}, {rw[2]:.2f})    "
          f"sum = {sum(rw):.2f}")
    print(f"  Eq.4  (beta1, beta2)         = ({CONFIG['beta1']:.2f}, {CONFIG['beta2']:.2f})    "
          f"sum = {CONFIG['beta1']+CONFIG['beta2']:.2f}")
    print(f"  Eq.5  (theta_a, theta_c)     = ({CONFIG['theta_anomaly']:.2f}, "
          f"{CONFIG['theta_context']:.2f})")
    print(f"  C3    rate_limit_threshold   = {CONFIG['rate_limit_threshold']} msg/s")
    print(f"  C3    iforest_trees          = {CONFIG['iforest_trees']}")
    print(f"  C3    iforest_contamination  = {CONFIG['iforest_contamination']:.2f}")
    print(f"  C2/C3 window_size            = {CONFIG['window_size']}")

    # ----- 2. Inject attacks -----
    # (round-robin interleave of the 8 sites FIRST, then inject; this order
    #  differs from run_federated_comparison.py)
    print("\n[2/4] Injecting attacks per Section 3.5 threat model ...")
    if args.no_inject:
        print("       --no-inject set: using only native CSV labels.")
    else:
        print("       interleaving events round-robin across the 8 device "
              "types first (emulates concurrent MQTT publishers on the "
              "same broker per Section 3.6.2, not a sequential CSV read)")
        events = interleave_by_site(events, site_key="device_type")
        events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX,
                                seed=args.seed)

    # ----- 3. Per-component trace demo (Eq.1 .. Eq.8) -----
    # Uses only the first 9,000 events and separate component instances.
    demonstrate_components(events[:9000], device_registry)

    # ----- 4. Bulk pipeline run  --  BEFORE federated (baseline C3) -----
    banner("OLD METRICS (Table-2, established evaluation matrix) -- pipeline run, baseline (Eq.3 only, no Eq.8)")
    n_bursts = len(events) - n_ton_iot
    print(f"   TON_IoT rows loaded         : {n_ton_iot:>7,}")
    print(f"   DoS/DDoS bursts inserted    : {n_bursts:>7,}")
    print(f"   Total to pass through C1..C7: {len(events):>7,}")
    print(f"   Unique devices              : {len(device_registry):,}")
    print()

    pipeline = CAEFPipeline(device_registry=device_registry,
                            keep_full_seals=bool(args.dump_evidence))
    # Constant simulated broker delay: every latency includes this 12 ms.
    BROKER_DELAY_NS = 12_000_000
    t0 = time.time()
    last_print = 0
    progress_every = max(500, len(events) // 20)   # print progress every 5 %
    for ev in events:
        pipeline.ingest(
            mqtt_packet = ev,
            source_id   = "edge_node_01",
            true_label  = ground_truth_label(ev, gt),
            t_broker_ns = time.time_ns() - BROKER_DELAY_NS,
        )
        if pipeline.total_events - last_print >= progress_every:
            pct = 100.0 * pipeline.total_events / len(events)
            print(f"   processed {pipeline.total_events:>7,} / {len(events):,}"
                  f"  ({pct:5.1f}%)   sealed so far = "
                  f"{len(pipeline.sealed_evidence):,}")
            last_print = pipeline.total_events
    wall = time.time() - t0
    print(f"   processed {pipeline.total_events:>7,} / {len(events):,}"
          f"  (100.0%)   sealed total = {len(pipeline.sealed_evidence):,}")
    print(f"   finished in {wall:.3f} s")

    # ----- 5. BEFORE-federated evaluation -----
    banner("OLD METRICS (Table-2) RESULTS -- BASELINE (before adding Eq.8)")
    before_results = print_report(
        decisions    = pipeline.all_decisions,
        latencies_ns = pipeline.latencies_ns,
        wall_clock_s = wall,
        total_events = pipeline.total_events,
        ton_iot_rows = n_ton_iot,
    )

    # Numbers of the baseline pass are written to results.json (current dir).
    results_path = Path("results.json")
    with open(results_path, "w") as fh:
        json.dump(before_results, fh, indent=2, default=str)
    print(f"\n[+] BEFORE-federated numeric results saved to {results_path.resolve()}")

    # ----- 6. Bulk pipeline run  --  AFTER federated (Eq.8, FedC3) -------
    banner("OLD METRICS (Table-2, established evaluation matrix) -- pipeline run, federated (Eq.3 + Eq.8)")
    # Fresh component instances (statistics start from zero) for a fair
    # second pass; only C3 is replaced by the federated engine (8 sites).
    fed_c1 = C1_StreamMonitor()
    fed_c2 = C2_FeatureEnrichment()
    fed_c3 = FedC3_AnomalyDetectionEngine(site_key="device_type")
    fed_c4 = C4_ContextAnalysisModule(device_registry=device_registry)
    fed_c5 = C5_TriggerDecisionUnit()
    fed_c6 = C6_EvidenceAcquisition()
    fed_c7 = C7_ProvenanceSealing()

    # ----- detailed local/global theta printing -----
    # The wrapper below only ADDS console output when a federated round
    # fires; it calls the original method unchanged.
    local_refit_count = {}
    _original_maybe_run_federated_round = fed_c3._maybe_run_federated_round

    # Wrapper that prints the local and global thresholds whenever a federated round fires.
    def _instrumented_maybe_run_federated_round():
        _before_round = fed_c3.fed_round
        _original_maybe_run_federated_round()
        _after_round = fed_c3.fed_round
        if _after_round > _before_round:
            print(f"\n{'='*78}")
            print(f"GLOBAL ROUND R = {_after_round}  (global_event_counter = "
                  f"{fed_c3._global_event_counter:,})")
            print(f"{'='*78}")
            print(f"{'site':<14}{'n_k':>10}{'theta_local,k':>16}{'weight n_k/N':>14}")
            _participants = fed_c3.last_round_participants
            _N = sum(fed_c3._sites[_sid].n_s for _sid in _participants)
            for _sid in _participants:
                _st = fed_c3._sites[_sid]
                _weight = _st.n_s / _N
                print(f"{_sid:<14}{_st.n_s:>10,}{_st.theta_local:>16.6f}{_weight:>14.6f}")
            print(f"{'-'*54}")
            print(f"{'theta_global^(' + str(_after_round) + ')':<38}= "
                  f"{fed_c3.theta_global:.6f}")

    fed_c3._maybe_run_federated_round = _instrumented_maybe_run_federated_round

    fed_latencies_ns, fed_decisions = [], []
    t0 = time.time()
    last_print = 0
    for ev in events:
        t_in_ns = time.time_ns() - BROKER_DELAY_NS
        e1 = fed_c1.process(dict(ev), source_id="edge_node_01")
        e2 = fed_c2.process(e1)

        # Site of this event (used only for the refit printout below).
        _site_id = ev.get("device_type", "unknown")
        e3 = fed_c3.process(e2)
        _st_after = fed_c3._sites.get(_site_id)
        # Print a line whenever a site has just performed a local refit
        # (n_s = 64, 4096, 8192, ...).  Informational only.
        if _st_after and _st_after.n_s in (64, 4096, 8192, 12288, 16384):
            local_refit_count[_site_id] = local_refit_count.get(_site_id, 0) + 1
            print(f"[LOCAL REFIT] site={_site_id:<14} refit #{local_refit_count[_site_id]}  "
                  f"n_s={_st_after.n_s:>7,}   theta_local,{_site_id} = "
                  f"{_st_after.theta_local:.6f}")

        e4 = fed_c4.process(e3)
        e5 = fed_c5.process(e4)
        if e5["d_i"] == 1:
            ea = fed_c6.process(e5)
            fed_c7.process(ea)
            fed_latencies_ns.append(time.time_ns() - t_in_ns)
        fed_decisions.append({
            "d_i": e5["d_i"], "true_label": ground_truth_label(ev, gt),
            "attack_type": ev.get("attack_type", "normal"),
        })
        if len(fed_decisions) - last_print >= progress_every:
            pct = 100.0 * len(fed_decisions) / len(events)
            print(f"   processed {len(fed_decisions):>7,} / {len(events):,}"
                  f"  ({pct:5.1f}%)")
            last_print = len(fed_decisions)
    fed_wall = time.time() - t0
    print(f"   processed {len(fed_decisions):>7,} / {len(events):,}  (100.0%)")
    print(f"   Eq.8a federated rounds fired : {fed_c3.fed_round}   "
          f"across {len(fed_c3._sites)} sites")
    print(f"   finished in {fed_wall:.3f} s")

    # ----- detailed local/global theta summary -----
    print(f"\n{'='*78}")
    print("FINAL SUMMARY -- theta_local per site, and theta_global")
    print(f"{'='*78}")
    print(f"{'site':<14}{'n_s':>10}{'local refits':>14}{'final theta_local':>20}")
    for _sid, _st in fed_c3._sites.items():
        print(f"{_sid:<14}{_st.n_s:>10,}{local_refit_count.get(_sid, 0):>14}"
              f"{_st.theta_local:>20.6f}")
    print(f"\nFinal theta_global (after R={fed_c3.fed_round} rounds): "
          f"{fed_c3.theta_global:.6f}")

    banner("OLD METRICS (Table-2) RESULTS -- FEDERATED (after adding Eq.8)")
    after_results = print_report(
        decisions    = fed_decisions,
        latencies_ns = fed_latencies_ns,
        wall_clock_s = fed_wall,
        total_events = len(events),
        ton_iot_rows = n_ton_iot,
    )

    # Numbers of the federated pass go to results_after_federated.json.
    after_path = Path("results_after_federated.json")
    with open(after_path, "w") as fh:
        json.dump(after_results, fh, indent=2, default=str)
    print(f"\n[+] AFTER-federated numeric results saved to {after_path.resolve()}")

    # ----- 7. Final side-by-side summary : BEFORE vs AFTER federated ----
    banner("OLD METRICS (Table-2) SUMMARY -- baseline vs federated, side by side")
    print(f"{'Metric':24s}{'Before (baseline)':>20s}{'After (+Eq.8)':>16s}")
    print(f"{'Mean L_E2E (ms)':24s}{before_results['m1_mean_ms']:20.3f}"
          f"{after_results['m1_mean_ms']:16.3f}")
    print(f"{'PR (%)':24s}{before_results['m2_PR']*100:20.2f}"
          f"{after_results['m2_PR']*100:16.2f}")
    print(f"{'P_trigger':24s}{before_results['m3_precision']:20.4f}"
          f"{after_results['m3_precision']:16.4f}")

    # ----- 8. Privacy metrics (computed from THIS run's fed_c3 instance) --
    banner("NEW METRICS (privacy, added for the Eq.8 federated extension)")
    # Data for both privacy metrics comes from the federated engine itself.
    priv_data = fed_c3.export_privacy_metric_data()

    # d = 10: the number of raw attributes per event (Eq. 1) a centralised
    # design would upload.
    comm_res = communication_cost_metric(
        K=priv_data["K"], R=priv_data["R"],
        per_site_event_counts=priv_data["per_site_event_counts"], d=10)
    print_communication_cost_report(comm_res)

    # Mutual information over one row per local refit (about 32 rows).  No
    # bootstrap confidence interval is computed in this archive.
    mi_res = mutual_information_leakage_metric(priv_data["mi_rows"])
    print_mi_leakage_report(mi_res)


if __name__ == "__main__":
    main()
