# FILE GUIDE
# Role      : end-to-end test against a LIVE Mosquitto broker (127.0.0.1:1883): publishes the
#             attack stream with attack_injector.broker_inject() and checks a subscriber
#             receives every message.  Not needed for the paper's simulated results.
"""
live_broker_test.py
===================
LIVE end-to-end demonstration that:

  (a) attack_injector.broker_inject() actually publishes the prepared
      Section-3.5 attack stream to a running Eclipse Mosquitto broker
      over MQTT v5.0, and

  (b) a CAEF C1_StreamMonitor subscriber on the other side of the
      broker receives the EXACT same byte-for-byte payloads, with all
      5,760 burst events delivered.

This is the practical proof that attack_injector is a NAMED component of
the simulation architecture, not just an in-process replay helper.

Pre-requisite:
    A Mosquitto broker must be running on 127.0.0.1:1883.
    On Ubuntu:    sudo apt-get install mosquitto
                  mosquitto -d
"""

import json
import time
import threading
from collections import Counter
from pathlib import Path

import paho.mqtt.client as mqtt

from attack_injector import (
    inject_attacks,
    broker_inject,
    count_burst_events,
    DEFAULT_ATTACK_MIX,
)
from ton_iot_loader import load_ton_iot, make_ton_iot_synthetic


BROKER_HOST = "127.0.0.1"
BROKER_PORT = 1883
BAR = "=" * 78


# Minimal MQTT v5 subscriber that counts received messages by attack_type.
class Subscriber:
    """Thin paho-mqtt v5 subscriber that just COUNTS messages by
    attack_type, demonstrating that broker_inject() really delivers."""

    # Create the MQTT v5 test subscriber.
    def __init__(self):
        self.client = mqtt.Client(client_id="caef_test_subscriber",
                                  protocol=mqtt.MQTTv5)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.received_by_class = Counter()
        self.total_received   = 0
        self.first_msg_ts     = None
        self.last_msg_ts      = None
        self._stop = False

    def _on_connect(self, client, userdata, flags, rc, properties=None):
        # Subscribe to EVERY topic so we count all classes
        client.subscribe("#", qos=1)

    # Count every message received from the broker.
    def _on_message(self, client, userdata, msg):
        try:
            ev = json.loads(msg.payload.decode("utf-8"))
            self.received_by_class[ev.get("attack_type", "unknown")] += 1
            self.total_received += 1
            now = time.time()
            if self.first_msg_ts is None:
                self.first_msg_ts = now
            self.last_msg_ts = now
        except Exception:
            self.received_by_class["malformed_payload"] += 1
            self.total_received += 1

    # Connect to the broker and start the network loop.
    def start(self):
        self.client.connect(BROKER_HOST, BROKER_PORT, keepalive=60)
        self.client.loop_start()

    # Stop the network loop and disconnect.
    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()


# Starts the subscriber, publishes the stream through the broker, compares counts.
def main():
    print(BAR)
    print(" CAEF -- LIVE broker integration test")
    print(BAR)
    print(f"   Broker        : tcp://{BROKER_HOST}:{BROKER_PORT}")
    print(f"   Protocol      : MQTT v5.0 (paho-mqtt)")
    print()

    # ----- 1. Prepare the event stream (real CSV if available) -------
    data_dir = Path("data")
    if data_dir.exists() and any(data_dir.glob("Train_Test_IoT_*.csv")):
        print("[1/4] Loading TON_IoT-style CSV ...")
        events, _ = load_ton_iot(str(data_dir), max_rows=None)
    else:
        print("[1/4] No CSVs found - using synthetic TON_IoT-style stream")
        events, _ = make_ton_iot_synthetic(n_per_device=12_200, seed=42)
    n_in = len(events)
    print(f"      base stream length: {n_in:,} events")

    # ----- 2. Inject attacks (the 5,760 figure) ----------------------
    print()
    print("[2/4] Injecting Section-3.5 attacks ...")
    plan = count_burst_events(n_in, DEFAULT_ATTACK_MIX)
    print(f"      formal plan: {plan['total_burst']:,} burst events "
          f"-> final {plan['final_count']:,}")
    events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX,
                            seed=42, verbose=False)
    n_out = len(events)
    print(f"      actual    : {n_out - n_in:,} burst events inserted")
    assert (n_out - n_in) == plan["total_burst"]

    # ----- 3. Spin up subscriber and publish via Mosquitto ----------
    print()
    print("[3/4] Spinning up subscriber on the broker ...")
    sub = Subscriber()
    sub.start()
    time.sleep(0.5)        # let subscription settle

    print("      publishing the stream via attack_injector.broker_inject() ...")
    t0 = time.time()
    publish_result = broker_inject(
        events       = events,
        broker_url   = f"tcp://{BROKER_HOST}:{BROKER_PORT}",
        rate_per_sec = 50_000.0,      # as fast as paho can go
        qos          = 1,
        verbose      = False,
    )
    publish_time = time.time() - t0

    # let the broker drain any in-flight messages
    time.sleep(2.0)
    sub.stop()

    # ----- 4. Compare published vs received --------------------------
    print()
    print("[4/4] Comparing publisher vs subscriber counts ...")
    pub_counts = publish_result["per_class"]
    sub_counts = dict(sub.received_by_class)

    print()
    print(f"  +{'-'*14}+{'-'*12}+{'-'*12}+{'-'*8}+")
    print(f"  | {'attack_type':<12} | {'published':>10} | {'received':>10} | {'match':>6} |")
    print(f"  +{'-'*14}+{'-'*12}+{'-'*12}+{'-'*8}+")
    all_match = True
    for cls in sorted(set(pub_counts) | set(sub_counts)):
        p = pub_counts.get(cls, 0)
        r = sub_counts.get(cls, 0)
        m = "OK" if p == r else "DIFF"
        if p != r:
            all_match = False
        print(f"  | {cls:<12} | {p:>10,} | {r:>10,} | {m:>6} |")
    print(f"  +{'-'*14}+{'-'*12}+{'-'*12}+{'-'*8}+")
    print(f"  | {'TOTAL':<12} | {publish_result['published']:>10,}"
          f" | {sub.total_received:>10,} | "
          f"{'OK' if publish_result['published'] == sub.total_received else 'DIFF':>6} |")
    print(f"  +{'-'*14}+{'-'*12}+{'-'*12}+{'-'*8}+")

    print()
    print(f"  Publish wall-clock : {publish_time:>7.3f} s "
          f"({n_out/publish_time:,.0f} msg/s)")
    if sub.first_msg_ts and sub.last_msg_ts:
        print(f"  Subscriber span    : "
              f"{sub.last_msg_ts - sub.first_msg_ts:>7.3f} s")

    print()
    if all_match and publish_result['published'] == sub.total_received:
        print(BAR)
        print("  LIVE BROKER TEST PASSED  -- every published event was received")
        print(BAR)
    else:
        print(BAR)
        print("  LIVE BROKER TEST: some events were dropped (QoS/network)")
        print(BAR)


if __name__ == "__main__":
    main()
