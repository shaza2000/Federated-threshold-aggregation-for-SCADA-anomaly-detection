# FILE GUIDE
# Role      : replays events as real MQTT v5 PUBLISH messages to a broker (needs paho-mqtt).
#             Optional; the paper's experiments run in-process without a broker.
"""
mqtt_publisher.py
=================
Real MQTT publisher (OASIS MQTT v5.0).  Replays TON_IoT events through a
Mosquitto broker so the CAEF subscriber receives them on the wire.

REQUIREMENTS:
    - Eclipse Mosquitto running locally (or anywhere)
    - pip install paho-mqtt

USAGE (two terminals):
    Terminal 1 :    python mqtt_subscriber.py
    Terminal 2 :    python mqtt_publisher.py --csv ./data/IoT_Modbus.csv

    OR with synthetic data:
    Terminal 2 :    python mqtt_publisher.py

The publisher emits one PUBLISH per event.  Attack events flip the same
MQTT-level fields (client_id, topic, keep_alive) so the subscriber sees a
*real* wire-level deviation - exactly what rules r1, r2, r3 detect in Eq. 3.
"""

import argparse
import json
import time

import paho.mqtt.client as mqtt
from paho.mqtt.client import MQTTv5

from ton_iot_loader import load_ton_iot_csv, make_synthetic_stream
from attack_injector import inject_attacks, DEFAULT_ATTACK_MIX


# Creates a connected MQTT v5 client (paho-mqtt).
def make_client(client_id: str, host: str, port: int):
    cli = mqtt.Client(client_id=client_id,
                      protocol=MQTTv5,
                      callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
    cli.connect(host, port, keepalive=60)
    cli.loop_start()
    return cli


# Publishes one event as JSON on its own topic (QoS 1).
def publish_event(client, event):
    """Publish a single event.  The full event dict (incl. label) becomes
    the payload so the subscriber can compute precision/recall against
    ground truth."""
    topic = event["topic"]
    qos = event.get("qos", 0)
    payload = json.dumps(event, default=str).encode("utf-8")
    client.publish(topic, payload, qos=qos)


# CLI: loads CSV or synthetic events, injects attacks and publishes them.
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="localhost")
    p.add_argument("--port", type=int, default=1883)
    p.add_argument("--csv", default=None)
    p.add_argument("--max-rows", type=int, default=20_000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--rate", type=float, default=200.0,
                   help="Target events/second (0 = as fast as possible)")
    p.add_argument("--no-inject", action="store_true")
    args = p.parse_args()

    if args.csv:
        events = load_ton_iot_csv(args.csv, max_rows=args.max_rows, seed=args.seed)
    else:
        events = make_synthetic_stream(n=5_000, seed=args.seed)
    if not args.no_inject:
        events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX, seed=args.seed)

    print(f"[publisher] connecting to mqtt://{args.host}:{args.port}")
    # publisher uses a single legitimate-looking client_id for benign traffic;
    # for attack events we open a separate client per malicious client_id so
    # Mosquitto really sees a different MQTT client identifier on the wire.
    benign_client = make_client("caef_replay_publisher", args.host, args.port)
    malicious_clients = {}

    print(f"[publisher] streaming {len(events):,} events at rate ~{args.rate}/s ...")
    t0 = time.time()
    interval = (1.0 / args.rate) if args.rate > 0 else 0.0
    for i, ev in enumerate(events):
        attack_type = ev.get("attack_type", "normal")
        if attack_type == "normal":
            publish_event(benign_client, ev)
        else:
            cid = ev["client_id"]
            if cid not in malicious_clients:
                try:
                    malicious_clients[cid] = make_client(cid, args.host, args.port)
                except Exception as e:
                    print(f"[publisher] could not open client {cid}: {e}")
                    malicious_clients[cid] = benign_client
            publish_event(malicious_clients[cid], ev)
        if interval and (i % 50 == 0):
            time.sleep(interval * 50)
        if i % 2000 == 0 and i > 0:
            print(f"[publisher] sent {i:,} / {len(events):,}")

    elapsed = time.time() - t0
    print(f"[publisher] done. {len(events):,} events in {elapsed:.2f}s "
          f"({len(events)/elapsed:.1f} ev/s)")
    # flush
    time.sleep(2)
    benign_client.loop_stop()
    benign_client.disconnect()
    for c in malicious_clients.values():
        try:
            c.loop_stop(); c.disconnect()
        except Exception:
            pass


if __name__ == "__main__":
    main()
