# FILE GUIDE
# Role      : compares every number quoted in the paper with the output files of the
#             scripts (run after run_simulation.py, run_multi_seed.py,
#             run_fca_multi_seed.py, fig3_class_means.py and tune_parameters.py).
# Usage     : python check_paper_numbers.py          (exit code 1 if any check fails)
# Note      : latency values depend on the machine, so they use a 0.1 ms tolerance.
"""Paper-versus-measurement consistency check."""
import csv, json, sys

ms = json.load(open("multi_seed_results.json"))
S, R = ms["summary"], ms["records"]
b = json.load(open("results.json")); f = json.load(open("results_after_federated.json"))
fca = json.load(open("fca_multi_seed_results.json"))
f3 = json.load(open("fig3_class_means.json"))
grid = list(csv.DictReader(open("tuning_summary.csv")))
pc = S["per_class_recall"]
above = [r["seed"] for r in R if r["MI_nats"] > r["MI_null_p95"]]
r0 = R[0]
gp = [float(g["PR_percent"]) for g in grid]; gq = [float(g["P_trigger"]) for g in grid]
best = max(grid, key=lambda g: float(g["F1"]))

# (label, measured, paper value, tolerance)
C = [
 ("events", b["total_events"], 103360, 0), ("CSV rows", b["ton_iot_rows"], 97600, 0),
 ("inserted DoS/DDoS", b["burst_events"], 5760, 0), ("attacks, seed 42", b["m2_volatile"], 23196, 0),
 ("PR baseline %", S["PR_base"]["mean"]*100, 86.16, .005), ("PR baseline sd", S["PR_base"]["sd"]*100, 0.15, .005),
 ("PR federated %", S["PR_fed"]["mean"]*100, 86.19, .005), ("PR federated sd", S["PR_fed"]["sd"]*100, 0.50, .005),
 ("delta PR", S["delta_PR_points"]["mean"], 0.03, .005), ("delta PR sd", S["delta_PR_points"]["sd"], 0.58, .005),
 ("precision baseline", S["prec_base"]["mean"], 0.673, .0005), ("precision baseline sd", S["prec_base"]["sd"], 0.003, .0005),
 ("precision federated", S["prec_fed"]["mean"], 0.507, .0005), ("precision federated sd", S["prec_fed"]["sd"], 0.028, .0005),
 ("delta precision", S["delta_precision"]["mean"], -0.166, .0005), ("delta precision sd", S["delta_precision"]["sd"], 0.031, .0005),
 ("FP baseline", S["FP_base"]["mean"], 9681, 0.5), ("FP federated", S["FP_fed"]["mean"], 19536, 0.5),
 ("TP baseline ~", S["TP_base"]["mean"], 19970, 10), ("TP federated ~", S["TP_fed"]["mean"], 19970, 10),
 ("recall backdoor base %", pc["backdoor_base"]["mean"]*100, 62.4, .05), ("recall backdoor fed %", pc["backdoor_fed"]["mean"]*100, 62.8, .05),
 ("recall scanning base %", pc["scanning_base"]["mean"]*100, 71.9, .05), ("recall scanning fed %", pc["scanning_fed"]["mean"]*100, 71.6, .05),
 ("recall injection %", pc["injection_base"]["mean"]*100, 100, 0), ("recall dos %", pc["dos_base"]["mean"]*100, 100, 0),
 ("recall ddos %", pc["ddos_base"]["mean"]*100, 100, 0), ("recall malformed %", pc["malformed_base"]["mean"]*100, 100, 0),
 ("latency baseline ms", S["lat_base_ms"]["mean"], 12.046, .1), ("latency federated ms", S["lat_fed_ms"]["mean"], 12.049, .1),
 ("R", r0["R"], 25, 0), ("Cost_FL", r0["Cost_FL"], 1600, 0), ("Cost_centralized", r0["Cost_central"], 4134400, 0),
 ("reduction", r0["Cost_central"]/r0["Cost_FL"], 2584, .5),
 ("MI seed 42", r0["MI_nats"], 0.828, .0005), ("MI all rows seed 42", r0["MI_all_rows_nats"], 1.564, .0005),
 ("cov baseline seed 42", r0["MI_cov"], -0.007, .0005), ("null mean seed 42", r0["MI_null_mean"], 0.34, .005),
 ("null p95 seed 42", r0["MI_null_p95"], 0.72, .005),
 ("MI mean", S["MI_nats"]["mean"], 0.54, .005), ("MI sd", S["MI_nats"]["sd"], 0.17, .005),
 ("null p95 mean", S["MI_null_p95"]["mean"], 0.71, .005), ("null p95 sd", S["MI_null_p95"]["sd"], 0.05, .005),
 ("seeds above null", len(above), 2, 0), ("seeds above null = 42,45", int(above == [42, 45]), 1, 0),
 ("MI std_comp", r0["MI_per_feature"]["std_comp"], 0.275, .0005), ("MI mean_comp", r0["MI_per_feature"]["mean_comp"], 0.191, .0005),
 ("MI mean_f1", r0["MI_per_feature"]["mean_f1"], 0.149, .0005), ("MI std_f2", r0["MI_per_feature"]["std_f2"], 0.127, .0005),
 ("MI std_f1", r0["MI_per_feature"]["std_f1"], 0.085, .0005),
 ("mean comp scanning", f3["scanning"], 2.944, .0005), ("mean comp backdoor", f3["backdoor"], 1.444, .0005),
 ("mean comp normal", f3["normal"], 0.459, .0005), ("mean comp dos", f3["dos"], 0.324, .0005),
 ("mean comp malformed", f3["malformed"], 0.467, .0005),
 ("FCA PR %", fca["PR_mean_sd"][0], 31.98, .005), ("FCA PR sd", fca["PR_mean_sd"][1], 1.05, .005),
 ("FCA precision", fca["precision_mean_sd"][0], 0.717, .0005), ("FCA precision sd", fca["precision_mean_sd"][1], 0.024, .0005),
 ("grid size", len(grid), 324, 0), ("grid PR min", min(gp), 3.6, .05), ("grid PR max", max(gp), 88.2, .05),
 ("grid precision min", min(gq), 0.41, .005), ("grid precision max", max(gq), 1.00, .005),
 ("grid best PR", float(best["PR_percent"]), 83.3, .05), ("grid best precision", float(best["P_trigger"]), 0.802, .0005),
 ("grid best alpha", float(best["alpha"]), 0.3, 0), ("grid best theta_a", float(best["theta_anomaly"]), 0.20, 0),
 ("grid best contamination", float(best["contamination"]), 0.15, 0),
]
# ---- second dataset (KDD Cup 99), Sec. 4.7 / Tab. 6-9 of the paper ----
def _k(name):
    return json.load(open(name))
KM = _k("kdd_matched_policy_results.json")["summary"]; KN = _k("kdd_natural_policy_results.json")["summary"]
KF = _k("kdd_matched_flat_results.json")["summary"]
KLm = _k("kdd_matched_localonly_results.json")["summary"]; KLn = _k("kdd_natural_localonly_results.json")["summary"]
TL = _k("multi_seed_localonly.json")["summary"]
KR = _k("kdd_matched_policy_results.json")["records"]; KNR = _k("kdd_natural_policy_results.json")["records"]
pm = KM["per_class_recall"]
C += [
 ("KDD matched events", KR[0]["events"], 113243, 0), ("KDD matched attacks", KR[0]["attack_rows"], 25412, 0),
 ("KDD natural events", KNR[0]["events"], 145585, 0), ("KDD natural attacks", KNR[0]["attack_rows"], 57754, 0),
 ("KDD matched PR base", KM["PR_base"]["mean"]*100, 18.92, .005), ("KDD matched PR base sd", KM["PR_base"]["sd"]*100, 0.62, .005),
 ("KDD matched PR fed", KM["PR_fed"]["mean"]*100, 72.31, .005), ("KDD matched PR fed sd", KM["PR_fed"]["sd"]*100, 5.37, .005),
 ("KDD matched prec base", KM["prec_base"]["mean"], 0.179, .0005), ("KDD matched prec fed", KM["prec_fed"]["mean"], 0.364, .0005),
 ("KDD matched F1 base", KM["F1_base"]["mean"], 0.184, .0005), ("KDD matched F1 fed", KM["F1_fed"]["mean"], 0.484, .0005),
 ("KDD matched delta PR", KM["delta_PR_points"]["mean"], 53.4, .05), ("KDD matched delta PR sd", KM["delta_PR_points"]["sd"], 5.3, .05),
 ("KDD natural PR base", KN["PR_base"]["mean"]*100, 17.37, .005), ("KDD natural PR fed", KN["PR_fed"]["mean"]*100, 84.06, .005),
 ("KDD natural prec base", KN["prec_base"]["mean"], 0.290, .0005), ("KDD natural prec fed", KN["prec_fed"]["mean"], 0.586, .0005),
 ("KDD natural F1 base", KN["F1_base"]["mean"], 0.217, .0005), ("KDD natural F1 fed", KN["F1_fed"]["mean"], 0.690, .0005),
 ("KDD natural delta PR", KN["delta_PR_points"]["mean"], 66.7, .05),
 ("KDD matched FCA PR", KM["PR_fca"]["mean"]*100, 32.69, .005), ("KDD matched FCA prec", KM["prec_fca"]["mean"], 0.754, .0005),
 ("KDD matched FCA F1", KM["F1_fca"]["mean"], 0.456, .0005), ("KDD natural FCA PR", KN["PR_fca"]["mean"]*100, 17.58, .005),
 ("KDD natural FCA prec", KN["prec_fca"]["mean"], 0.766, .0005), ("KDD natural FCA F1", KN["F1_fca"]["mean"], 0.285, .0005),
 ("KDD matched local-only PR", KLm["PR_fed"]["mean"]*100, 20.85, .005), ("KDD natural local-only PR", KLn["PR_fed"]["mean"]*100, 26.54, .005),
 ("TON local-only PR", TL["PR_fed"]["mean"]*100, 86.16, .005), ("TON local-only prec", TL["prec_fed"]["mean"], 0.536, .0005),
 ("KDD flat-registry PR", KF["PR_fed"]["mean"]*100, 72.69, .005),
 ("KDD matched MI", KM["MI_nats"]["mean"], 0.880, .0005), ("KDD matched null p95", KM["MI_null_p95"]["mean"], 0.710, .0005),
 ("KDD natural MI", KN["MI_nats"]["mean"], 1.220, .0005), ("KDD natural null p95", KN["MI_null_p95"]["mean"], 0.682, .0005),
 ("KDD matched seeds above null", KM["above_null"], 7, 0), ("KDD natural seeds above null", KN["above_null"], 10, 0),
 ("KDD matched R", KR[0]["R"], 27, 0), ("KDD natural R", KNR[0]["R"], 35, 0),
 ("KDD matched Cost_FL", KR[0]["Cost_FL"], 1728, 0), ("KDD natural Cost_FL", KNR[0]["Cost_FL"], 2240, 0),
 ("KDD matched reduction", KR[0]["Cost_central"]/KR[0]["Cost_FL"], 2621, .5), ("KDD natural reduction", KNR[0]["Cost_central"]/KNR[0]["Cost_FL"], 2600, .5),
 ("KDD DoS recall base %", pm["dos_base"]["mean"]*100, 17.4, .05), ("KDD DoS recall fed %", pm["dos_fed"]["mean"]*100, 72.5, .05),
 ("KDD probe recall base %", pm["probe_base"]["mean"]*100, 40.7, .05), ("KDD probe recall fed %", pm["probe_fed"]["mean"]*100, 73.3, .05),
 ("KDD R2L recall base %", pm["r2l_base"]["mean"]*100, 50.0, .06), ("KDD R2L recall fed %", pm["r2l_fed"]["mean"]*100, 57.8, .05),
 ("KDD U2R recall base %", pm["u2r_base"]["mean"]*100, 97.9, .05), ("KDD U2R recall fed %", pm["u2r_fed"]["mean"]*100, 94.5, .05),
]
# injected protocol (TON_IoT attack process applied to the KDD normal records)
KI = _k("kdd_injected_policy_results.json")["summary"]; KIR = _k("kdd_injected_policy_results.json")["records"]
KIL = _k("kdd_injected_localonly_results.json")["summary"]
C += [
 ("KDD inj events", KIR[0]["events"], 103037, 0), ("KDD inj R", KIR[0]["R"], 25, 0),
 ("KDD inj PR base", KI["PR_base"]["mean"]*100, 94.86, .005), ("KDD inj PR fed", KI["PR_fed"]["mean"]*100, 92.90, .005),
 ("KDD inj prec base", KI["prec_base"]["mean"], 0.649, .0005), ("KDD inj prec fed", KI["prec_fed"]["mean"], 0.558, .0005),
 ("KDD inj F1 fed", KI["F1_fed"]["mean"], 0.696, .0005), ("KDD inj delta PR", KI["delta_PR_points"]["mean"], -1.96, .005),
 ("KDD inj delta prec", KI["delta_precision"]["mean"], -0.091, .0005),
 ("KDD inj local-only PR", KIL["PR_fed"]["mean"]*100, 90.66, .005), ("KDD inj local-only prec", KIL["prec_fed"]["mean"], 0.611, .0005),
 ("KDD inj FCA PR", KI["PR_fca"]["mean"]*100, 23.0, .05), ("KDD inj FCA prec", KI["prec_fca"]["mean"], 0.760, .0005),
 ("KDD inj MI", KI["MI_nats"]["mean"], 0.460, .0005), ("KDD inj null p95", KI["MI_null_p95"]["mean"], 0.681, .0005),
 ("KDD inj seeds above null", KI["above_null"], 3, 0),
 ("KDD inj reduction", KIR[0]["Cost_central"]/KIR[0]["Cost_FL"], 2576, .5),
]
bad = 0
print(f"{'check':28s}{'measured':>14s}{'paper':>12s}  status")
for name, m, p, tol in C:
    ok = abs(m - p) <= tol + 1e-9
    bad += (not ok)
    print(f"{name:28s}{m:14.4f}{p:12.4f}  {'OK' if ok else 'MISMATCH'}")
print(f"\n{len(C) - bad} of {len(C)} checks passed")
sys.exit(1 if bad else 0)
