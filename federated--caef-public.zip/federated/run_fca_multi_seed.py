# FILE GUIDE
# Role      : runs the FCA baseline (run_fca_evaluation.py) for several seeds and
#             prints mean +/- sample SD of PR and trigger precision.
# Usage     : python run_fca_multi_seed.py --csv data/ --seeds 42-51
# Output    : fca_multi_seed_results.json
"""FCA baseline over several attack-placement seeds (same streams as run_multi_seed.py)."""
import argparse, json, statistics as st, contextlib, io
import run_fca_evaluation as F

# Run the FCA baseline for each seed and print mean and standard deviation.
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/")
    ap.add_argument("--seeds", default="42-51")
    a = ap.parse_args()
    lo, hi = a.seeds.split("-") if "-" in a.seeds else (a.seeds, a.seeds)
    recs = []
    for seed in range(int(lo), int(hi) + 1):
        with contextlib.redirect_stdout(io.StringIO()):       # silence per-run prints
            events, _ = F.load_same_stream_as_caef(a.csv, seed)
            res = F.run_fca_pipeline(events)
        recs.append({"seed": seed, "PR": res["m2_PR"], "precision": res["m3_precision"],
                     "TP": res["m3_TP"], "FP": res["m3_FP"], "latency_ms": res["m1_mean_ms"]})
        print(f"seed {seed}: PR {res['m2_PR']*100:.2f}%  precision {res['m3_precision']:.4f}", flush=True)
    pr = [r["PR"] * 100 for r in recs]; pc = [r["precision"] for r in recs]
    out = {"records": recs, "PR_mean_sd": [st.mean(pr), st.stdev(pr)],
           "precision_mean_sd": [st.mean(pc), st.stdev(pc)]}
    json.dump(out, open("fca_multi_seed_results.json", "w"), indent=1)
    print(f"\nFCA PR        {out['PR_mean_sd'][0]:.2f} +/- {out['PR_mean_sd'][1]:.2f} %")
    print(f"FCA precision {out['precision_mean_sd'][0]:.4f} +/- {out['precision_mean_sd'][1]:.4f}")
    print(f"FCA latency   {recs[0]['latency_ms']:.2f} ms (constant, not measured)")

if __name__ == "__main__":
    main()
