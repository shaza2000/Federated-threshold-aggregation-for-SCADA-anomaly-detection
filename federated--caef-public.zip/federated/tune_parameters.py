# FILE GUIDE
# Role      : grid search over CAEF hyper-parameters (supports the Section 3.6 claim).
# Inputs    : TON_IoT-style CSVs (--csv), attack seed (--seed).
# Outputs   : tuning_results.json, tuning_summary.csv, console ranking.
# The trial values for alpha, theta_anomaly, theta_context, beta and
#  contamination are written onto the live pipeline objects in run_one_trial.
# The stream is interleaved by site and uses the injected-attacks-only ground
#  truth, like run_simulation.py.  KNOWN LIMITATION: the grid is scored on the
#  same stream and labels that are later reported (no train / test split); no
#  grid over beta1 / beta2 exists.  --shard i/n splits the grid over processes.
"""
tune_parameters.py
==================
Grid-search over the CAEF hyperparameters defined in CONFIG (Section 3.6
of the methodology) and report which combination maximises a chosen
objective.

Searched parameters
-------------------
    alpha           : OIF vs rules fusion weight  in Eq.3
    w1, w2, w3      : per-rule weights for r1, r2, r3  (must sum to 1.0)
    theta_anomaly   : anomaly threshold in Eq.5
    theta_context   : context  threshold in Eq.5
    contamination   : Isolation Forest contamination parameter

Objectives
----------
    f1          : harmonic mean of PR (recall) and P_trigger (precision)
    pr          : maximise Preservation Rate  (more attacks sealed)
    precision   : maximise Trigger Precision  (fewer false positives)
    balanced    : 0.5 * PR + 0.5 * P_trigger

Usage
-----
    python tune_parameters.py --csv data/                  # full grid
    python tune_parameters.py --csv data/ --quick          # ~24 trials
    python tune_parameters.py --csv data/ --objective pr   # maximise PR
    python tune_parameters.py --csv data/ --top 10         # show top-10

Outputs:
    tuning_results.json   -- every trial with its 3 metrics
    tuning_summary.csv    -- same data, importable into Excel/LaTeX
    The winning configuration is also printed to the terminal in the
    format you can paste straight into caef.py CONFIG.
"""

import argparse
import copy
import csv
import itertools
import json
import time
from pathlib import Path

import caef
from caef import CAEFPipeline, CONFIG
from ton_iot_loader import load_ton_iot, make_synthetic_stream
from attack_injector import inject_attacks, ground_truth_label
from run_simulation import interleave_by_site   # same stream order as run_simulation.py
from evaluation import (
    end_to_end_latency_ms,
    preservation_rate,
    trigger_precision,
)


# =========================================================================
# 1) Grid definitions
# -------------------------------------------------------------------------
# These ranges cover the operating envelope discussed in Section 3.6.
# Adjust to taste; the script handles any number of points.
# =========================================================================
FULL_GRID = {
    "alpha":           [0.3, 0.5, 0.7],
    "rule_weights":    [
        (0.50, 0.30, 0.20),
        (0.60, 0.25, 0.15),
        (0.70, 0.20, 0.10),
    ],
    "theta_anomaly":   [0.20, 0.30, 0.40, 0.50],
    "theta_context":   [0.30, 0.50, 0.70],
    "iforest_contamination": [0.05, 0.15, 0.30],
}

QUICK_GRID = {
    "alpha":           [0.5],
    "rule_weights":    [
        (0.60, 0.25, 0.15),
        (0.50, 0.30, 0.20),
    ],
    "theta_anomaly":   [0.25, 0.30, 0.35],
    "theta_context":   [0.50],
    "iforest_contamination": [0.10, 0.20],
}


# =========================================================================
# 2) Evaluation primitives -- identical to evaluation.py but silent
# =========================================================================
# (see FILE GUIDE: only some CONFIG keys influence a trial)
def run_one_trial(events, device_registry, ton_iot_rows) -> dict:
    """Run the CAEF pipeline once with the current global CONFIG."""
    pipeline = CAEFPipeline(device_registry=device_registry)
    # Constructor defaults are bound at import time, so changing CONFIG afterwards
    # has no effect; push the trial values onto the live objects instead.
    pipeline.c3.alpha = CONFIG["alpha"]
    pipeline.c3.contamination = CONFIG["iforest_contamination"]
    pipeline.c4.beta1 = CONFIG["beta1"]
    pipeline.c4.beta2 = CONFIG["beta2"]
    pipeline.c5.theta_a = CONFIG["theta_anomaly"]
    pipeline.c5.theta_c = CONFIG["theta_context"]
    pipeline.c3.w = CONFIG["rule_weights"]
    t0 = time.time()
    BROKER_DELAY_NS = 12_000_000
    for ev in events:
        pipeline.ingest(
            mqtt_packet = ev,
            source_id   = "edge_node_01",
            true_label  = ground_truth_label(ev, "injected"),
            t_broker_ns = time.time_ns() - BROKER_DELAY_NS,
        )
    wall = time.time() - t0

    m1 = end_to_end_latency_ms(pipeline.latencies_ns)
    m2 = preservation_rate(pipeline.all_decisions)
    m3 = trigger_precision(pipeline.all_decisions)

    pr_v   = m2["PR"]
    prec_v = m3["P_trigger"]
    f1_v   = (2 * pr_v * prec_v / (pr_v + prec_v)) if (pr_v + prec_v) > 0 else 0.0

    return {
        "ton_iot_rows":   ton_iot_rows,
        "total_events":   pipeline.total_events,
        "wall_clock_s":   wall,
        "throughput":     pipeline.total_events / wall if wall > 0 else 0,
        "m1_mean_ms":     m1["mean_ms"],
        "m1_p95_ms":      m1["p95_ms"],
        "m1_sealed":      m1["n"],
        "m2_volatile":    m2["n_volatile"],
        "m2_sealed":      m2["n_sealed"],
        "m2_PR":          pr_v,
        "m3_TP":          m3["TP"],
        "m3_FP":          m3["FP"],
        "m3_precision":   prec_v,
        "f1":             f1_v,
        "balanced":       0.5 * pr_v + 0.5 * prec_v,
    }


# =========================================================================
# 3) Grid expander
# =========================================================================
# Cartesian product of all value lists -> one dict per configuration.
def expand_grid(grid: dict):
    keys   = list(grid.keys())
    values = [grid[k] for k in keys]
    for combo in itertools.product(*values):
        yield dict(zip(keys, combo))


# =========================================================================
# 4) Pretty printers
# =========================================================================
# One-line text description of a configuration for the console.
def fmt_cfg(cfg):
    rw = cfg["rule_weights"]
    return (f"alpha={cfg['alpha']:.2f}  "
            f"w=({rw[0]:.2f},{rw[1]:.2f},{rw[2]:.2f})  "
            f"theta_a={cfg['theta_anomaly']:.2f}  "
            f"theta_c={cfg['theta_context']:.2f}  "
            f"cont={cfg['iforest_contamination']:.2f}")


# Console line for one finished trial (PR, precision, F1).
def print_trial(idx, total, cfg, res):
    print(f"  [{idx:>3d}/{total}]  {fmt_cfg(cfg):<78s}"
          f"  PR={res['m2_PR']*100:6.2f}%"
          f"  P={res['m3_precision']:.3f}"
          f"  F1={res['f1']:.3f}")


# =========================================================================
# 5) Main driver
# =========================================================================
def main():
    parser = argparse.ArgumentParser(
        description="Grid-search the CAEF hyperparameters")
    parser.add_argument("--csv", required=True,
                        help="TON_IoT CSV file or directory")
    parser.add_argument("--max-rows", type=int, default=None,
                        help="Cap on TON_IoT rows (default: all)")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--quick", action="store_true",
                        help="Use a smaller grid (~12-24 trials)")
    parser.add_argument("--objective", choices=["f1", "pr", "precision", "balanced"],
                        default="f1",
                        help="Which metric to maximise (default: f1)")
    parser.add_argument("--top", type=int, default=5,
                        help="How many top results to print (default: 5)")
    parser.add_argument("--shard", default="0/1",
                        help="i/n: evaluate only every n-th configuration starting at i (parallel runs)")
    parser.add_argument("--out-json", default="tuning_results.json")
    parser.add_argument("--out-csv",  default="tuning_summary.csv")
    args = parser.parse_args()

    # --- 1. Load events ONCE; reuse across trials ---
    print("[load] loading TON_IoT events ...")
    events, device_registry = load_ton_iot(args.csv, max_rows=args.max_rows)
    ton_iot_rows = len(events)
    print(f"[load] interleaving by site, then injecting attacks ...")
    events = interleave_by_site(events, site_key="device_type")
    events = inject_attacks(events, seed=args.seed)
    print(f"[load] ready -- {len(events):,} events, {len(device_registry):,} devices")

    # --- 2. Pick grid ---
    grid = QUICK_GRID if args.quick else FULL_GRID
    combos = list(expand_grid(grid))
    _si, _sn = (int(x) for x in args.shard.split("/"))
    combos = combos[_si::_sn]
    total = len(combos)
    obj_key_map = {
        "f1":         "f1",
        "pr":         "m2_PR",
        "precision":  "m3_precision",
        "balanced":   "balanced",
    }
    obj_key = obj_key_map[args.objective]
    print(f"\n[grid] {total} configurations to evaluate "
          f"(objective: maximise {args.objective})")
    print()

    # --- 3. Iterate ---
    results = []
    t_start = time.time()
    for i, cfg in enumerate(combos, 1):
        # Mutate the GLOBAL CONFIG. CAEFPipeline reads CONFIG values at
        # __init__ (alpha, window_size, contamination) and during process()
        # (rule_weights, thetas, beta1, beta2), so updating in-place works.
        for k, v in cfg.items():
            CONFIG[k] = v
            caef.CONFIG[k] = v

        # NOTE: we must rebuild ALL pipeline objects per trial because C3
        # carries internal Welford state and a fitted IsolationForest.
        res = run_one_trial(events, device_registry, ton_iot_rows)
        res["config"] = cfg
        results.append(res)
        print_trial(i, total, cfg, res)

    t_total = time.time() - t_start
    print(f"\n[grid] all {total} trials done in {t_total:.1f} s "
          f"(avg {t_total/total:.2f} s/trial)")

    # --- 4. Rank and print top-N ---
    results.sort(key=lambda r: r[obj_key], reverse=True)

    print()
    print("=" * 90)
    print(f" TOP {args.top}  (ranked by {args.objective})")
    print("=" * 90)
    print(f" {'#':<3} {'config':<78}  {'PR':>7}  {'P':>6}  {'F1':>6}")
    print("-" * 90)
    for rank, r in enumerate(results[:args.top], 1):
        print(f" {rank:<3} {fmt_cfg(r['config']):<78}  "
              f"{r['m2_PR']*100:6.2f}%  "
              f"{r['m3_precision']:.3f}  "
              f"{r['f1']:.3f}")

    _prs = [r["m2_PR"] * 100 for r in results]
    _pcs = [r["m3_precision"] for r in results]
    print(f"\n[grid] {len(results)} configurations: PR range {min(_prs):.1f}-{max(_prs):.1f} %, "
          f"precision range {min(_pcs):.2f}-{max(_pcs):.2f}")

    # --- 5. Pretty-print the winner so you can paste into caef.py ---
    best = results[0]
    bc   = best["config"]
    print()
    print("=" * 90)
    print(" WINNING CONFIGURATION  (paste this into the CONFIG dict in caef.py)")
    print("=" * 90)
    print(f'    "alpha":                 {bc["alpha"]},')
    print(f'    "rule_weights":          ({bc["rule_weights"][0]}, '
          f'{bc["rule_weights"][1]}, {bc["rule_weights"][2]}),')
    print(f'    "theta_anomaly":         {bc["theta_anomaly"]},')
    print(f'    "theta_context":         {bc["theta_context"]},')
    print(f'    "iforest_contamination": {bc["iforest_contamination"]},')
    print()
    print(f"  -> Mean Latency  : {best['m1_mean_ms']:.2f} ms"
          f"  (p95 = {best['m1_p95_ms']:.2f} ms)")
    print(f"  -> Preservation  : {best['m2_PR']*100:.2f} %")
    print(f"  -> Trigger Prec. : {best['m3_precision']:.4f}")
    print(f"  -> F1            : {best['f1']:.4f}")
    print("=" * 90)

    # --- 6. Save all trials ---
    with open(args.out_json, "w") as fh:
        json.dump({
            "objective":     args.objective,
            "ton_iot_rows":  ton_iot_rows,
            "total_events":  results[0]["total_events"],
            "trials":        results,
        }, fh, indent=2, default=str)
    print(f"\n[+] all trials saved to  {Path(args.out_json).resolve()}")

    with open(args.out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow([
            "rank", "alpha", "w1", "w2", "w3",
            "theta_anomaly", "theta_context", "contamination",
            "PR_percent", "P_trigger", "F1",
            "mean_latency_ms", "p95_latency_ms",
            "TP", "FP", "throughput_ev_s",
        ])
        for rank, r in enumerate(results, 1):
            c = r["config"]
            w.writerow([
                rank,
                c["alpha"],
                c["rule_weights"][0], c["rule_weights"][1], c["rule_weights"][2],
                c["theta_anomaly"], c["theta_context"], c["iforest_contamination"],
                f"{r['m2_PR']*100:.4f}",
                f"{r['m3_precision']:.4f}",
                f"{r['f1']:.4f}",
                f"{r['m1_mean_ms']:.4f}",
                f"{r['m1_p95_ms']:.4f}",
                r["m3_TP"], r["m3_FP"],
                f"{r['throughput']:.1f}",
            ])
    print(f"[+] CSV summary saved to {Path(args.out_csv).resolve()}")


if __name__ == "__main__":
    main()
