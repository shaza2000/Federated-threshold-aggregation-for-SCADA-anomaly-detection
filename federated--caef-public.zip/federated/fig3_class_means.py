# FILE GUIDE
# Role      : reproduces the class-wise mean of comp_i = 0.5(|f1|+|f2|) quoted in the
#             Limitations section (mean over the eight sites' final 4096-event windows).
# Usage     : python fig3_class_means.py --csv data/ --seed 42
# Output    : fig3_class_means.json
"""Class-wise mean deviation magnitude in each site's final calibration window."""
import argparse, json
from collections import defaultdict, deque
import numpy as np
from caef import C1_StreamMonitor, C2_FeatureEnrichment, CONFIG
from ton_iot_loader import load_ton_iot
from attack_injector import inject_attacks, DEFAULT_ATTACK_MIX
from run_simulation import interleave_by_site

# Replay the stream through C1-C2 and print the class-wise mean of comp_i in the final windows.
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--csv", default="data/"); ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    events, _ = load_ton_iot(a.csv)
    events = interleave_by_site(events, site_key="device_type")
    events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX, seed=a.seed)
    c1, c2 = C1_StreamMonitor(), C2_FeatureEnrichment()
    win = defaultdict(lambda: deque(maxlen=CONFIG["window_size"]))     # last 4096 events per site
    for ev in events:
        e = c2.process(c1.process(dict(ev), source_id="edge_node_01"))
        comp = 0.5 * (abs(e["f1_temperature_zscore"]) + abs(e["f2_humidity_zscore"]))
        win[ev["device_type"]].append((ev.get("attack_type", "normal"), comp))
    by = defaultdict(list)
    for dq in win.values():
        for cls, comp in dq: by[cls].append(comp)
    res = {c: float(np.mean(v)) for c, v in by.items()}
    json.dump(res, open("fig3_class_means.json", "w"), indent=1)
    for c, v in sorted(res.items()): print(f"  {c:10s} mean comp = {v:.3f}   (n = {len(by[c])})")

if __name__ == "__main__":
    main()
