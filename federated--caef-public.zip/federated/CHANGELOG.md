# Change log

Behavioural changes:
1. caef.py: rule r2 uses a deterministic virtual clock (CONFIG["r2_clock"], ["sim_event_rate_hz"]); the "wall" mode is kept as an option.
2. attack_injector.py: `INJECTED_ATTACK_TYPES`, `ground_truth_label()`; drivers default to injected-attacks-only ground truth (`--ground-truth all` includes native label-1 rows).
3. privacy_metrics.py: MI headline uses full-window rows only; also returns the all-rows value, a permutation null and the estimator name.
4. tune_parameters.py: trial values are applied to the live pipeline objects.
5. run_multi_seed.py (mean +/- sd over seeds), run_fca_multi_seed.py, fig3_class_means.py, check_paper_numbers.py added.
6. run_fca_evaluation.py: injected-attacks-only ground truth; interleaving and seed handling as in run_simulation.py.
7. tune_parameters.py: interleaved stream, --shard option; full-grid outputs in tuning_results.json / tuning_summary.csv.
8. New kdd_loader.py and run_kdd_validation.py: independent-dataset validation on KDD Cup 99 (matched / natural streams, flat-registry ablation, local-only control, FCA baseline).
9. run_multi_seed.py and run_kdd_validation.py: `--fed-lambda` option (0 = local-only control).
10. check_paper_numbers.py extended to 138 checks (KDD results, local-only controls).
11. run_simulation.py: uses data/ automatically when it contains CSV files and prints a warning when it falls back to the synthetic generator.
12. run_kdd_validation.py: `--protocol injected` applies the TON_IoT injection process to the KDD normal records (`install_scaled_injector`); results and checks added.
