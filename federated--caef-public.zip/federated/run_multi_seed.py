# FILE GUIDE
# Role      : repeats the baseline-vs-federated comparison of run_simulation.py for
#             several attack-placement seeds (default 42..51) and reports
#             mean +/- sample standard deviation (ddof = 1) for every headline
#             metric.  This is the script that backs "ten runs, mean +/- sd".
# Pipeline  : identical order to run_simulation.py: load CSVs -> round-robin
#             interleave by device type -> inject attacks (seed) -> baseline C3 run
#             -> federated (FedC3) run.  Ground truth = injected attacks only
#             (attack_injector.ground_truth_label); an all-label PR is also stored.
# Outputs   : multi_seed_results.json (per-seed records), multi_seed_summary.csv.
# Usage     : python run_multi_seed.py --csv data/ --seeds 42-51
"""
run_multi_seed.py
=================
Multi-seed driver for the baseline (centralised OIF) versus federated (FedC3)
comparison.  Only the attack placement depends on the seed; the Isolation
Forest random_state stays at its fixed value, and rule r2 uses the virtual
clock (CONFIG["r2_clock"] = "virtual"), so every run is reproducible.
"""

import argparse
import contextlib
import csv
import io
import json
import statistics as st
import time

import numpy as np

from caef import CAEFPipeline, CONFIG
from federated_caef import FedC3_AnomalyDetectionEngine
from ton_iot_loader import load_ton_iot
from attack_injector import inject_attacks, DEFAULT_ATTACK_MIX, ground_truth_label
from evaluation import print_report
from privacy_metrics import (communication_cost_metric,
                             mutual_information_leakage_metric)
from run_simulation import interleave_by_site

BROKER_DELAY_NS = 12_000_000     # constant simulated broker delay (as in run_simulation.py)


def run_pass(events, registry, fed, fed_lambda=1.0):
    """One pass of the whole stream through C1..C7.  fed=True swaps C3 for the
    federated engine.  Returns (metrics dict, pipeline)."""
    p = CAEFPipeline(device_registry=registry)
    if fed:
        p.c3 = FedC3_AnomalyDetectionEngine(site_key="device_type",
                                            fed_lambda=fed_lambda)
    for ev in events:
        p.ingest(dict(ev), source_id="edge_node_01",
                 true_label=ground_truth_label(ev, "injected"),
                 t_broker_ns=time.time_ns() - BROKER_DELAY_NS)
    with contextlib.redirect_stdout(io.StringIO()):       # silence the report
        res = print_report(decisions=p.all_decisions, latencies_ns=p.latencies_ns,
                           wall_clock_s=1.0, total_events=p.total_events)
    # PR under the legacy "all labels" definition (adds native label-1 rows)
    vol = sum(1 for ev in events if int(ev.get("label", 0)) == 1)
    seal = sum(1 for ev, d in zip(events, p.all_decisions)
               if int(ev.get("label", 0)) == 1 and d["d_i"] == 1)
    res["PR_all_labels"] = seal / vol if vol else 0.0
    return res, p


# Parse a seed range such as 42-51 or a comma list.
def parse_seeds(txt):
    if "-" in txt:
        a, b = txt.split("-")
        return list(range(int(a), int(b) + 1))
    return [int(x) for x in txt.split(",")]


# Run baseline and federated passes for every seed, then aggregate and save the results.
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="data/")
    ap.add_argument("--seeds", default="42-51")
    ap.add_argument("--fed-lambda", type=float, default=1.0,
                    help="damping lambda of Eq. 8b; 0 = local-only control (no shared threshold)")
    ap.add_argument("--out-json", default="multi_seed_results.json")
    ap.add_argument("--out-csv", default="multi_seed_summary.csv")
    args = ap.parse_args()

    records = []
    for seed in parse_seeds(args.seeds):
        events, registry = load_ton_iot(args.csv)
        events = interleave_by_site(events, site_key="device_type")
        events = inject_attacks(events, attack_mix=DEFAULT_ATTACK_MIX, seed=seed)
        base, _ = run_pass(events, registry, fed=False)
        fed, pf = run_pass(events, registry, fed=True, fed_lambda=args.fed_lambda)
        priv = pf.c3.export_privacy_metric_data()
        comm = communication_cost_metric(
            K=priv["K"], R=priv["R"],
            per_site_event_counts=priv["per_site_event_counts"], d=10)
        mi = mutual_information_leakage_metric(priv["mi_rows"])
        rec = {
            "seed": seed, "events": len(events),
            "PR_base": base["m2_PR"], "PR_fed": fed["m2_PR"],
            "prec_base": base["m3_precision"], "prec_fed": fed["m3_precision"],
            "TP_base": base["m3_TP"], "FP_base": base["m3_FP"],
            "TP_fed": fed["m3_TP"], "FP_fed": fed["m3_FP"],
            "lat_base_ms": base["m1_mean_ms"], "lat_fed_ms": fed["m1_mean_ms"],
            "PR_all_labels_base": base["PR_all_labels"],
            "PR_all_labels_fed": fed["PR_all_labels"],
            "per_class_base": base["per_class"], "per_class_fed": fed["per_class"],
            "R": priv["R"], "Cost_FL": comm["Cost_FL_bytes"],
            "Cost_central": comm["Cost_centralized_bytes"],
            "MI_nats": mi.get("I_XB_Gt_nats"),
            "MI_all_rows_nats": mi.get("I_all_rows_nats"),
            "MI_null_p95": mi.get("permutation_null_p95_nats"),
            "MI_rows_used": mi.get("n_rows_used"),
            "MI_null_mean": mi.get("permutation_null_mean_nats"),
            "MI_cov": mi.get("C_XB_Gt_covariance_baseline"),
            "MI_per_feature": mi.get("mi_per_feature_nats"),
        }
        records.append(rec)
        print(f"seed {seed}: PR {rec['PR_base']*100:.2f}->{rec['PR_fed']*100:.2f}  "
              f"prec {rec['prec_base']:.4f}->{rec['prec_fed']:.4f}  "
              f"MI {rec['MI_nats']:.3f} (null p95 {rec['MI_null_p95']:.3f})", flush=True)

    # ---- aggregate: mean and sample standard deviation (ddof = 1) ----
    keys = [k for k in records[0] if isinstance(records[0][k], (int, float))
            and k not in ("seed",)]
    summary = {}
    for k in keys:
        v = [r[k] for r in records if r[k] is not None]
        summary[k] = {"mean": float(np.mean(v)),
                      "sd": float(st.stdev(v)) if len(v) > 1 else 0.0,
                      "min": float(min(v)), "max": float(max(v))}
    # per-seed paired differences
    d_pr = [(r["PR_fed"] - r["PR_base"]) * 100 for r in records]
    d_pc = [(r["prec_fed"] - r["prec_base"]) for r in records]
    summary["delta_PR_points"] = {"mean": float(np.mean(d_pr)),
                                  "sd": float(st.stdev(d_pr)) if len(d_pr) > 1 else 0.0}
    summary["delta_precision"] = {"mean": float(np.mean(d_pc)),
                                  "sd": float(st.stdev(d_pc)) if len(d_pc) > 1 else 0.0}
    # per-class recall (injected classes), mean +/- sd
    classes = sorted({c for r in records for c in r["per_class_base"]})
    summary["per_class_recall"] = {}
    for c in classes:
        for tag in ("base", "fed"):
            v = [r[f"per_class_{tag}"][c]["detected"] / r[f"per_class_{tag}"][c]["total"]
                 for r in records if r[f"per_class_{tag}"].get(c, {}).get("total")]
            if v:
                summary["per_class_recall"][f"{c}_{tag}"] = {
                    "mean": float(np.mean(v)),
                    "sd": float(st.stdev(v)) if len(v) > 1 else 0.0}

    with open(args.out_json, "w") as fh:
        json.dump({"records": records, "summary": summary}, fh, indent=2)
    with open(args.out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["metric", "mean", "sd", "min", "max"])
        for k, v in summary.items():
            if k == "per_class_recall":
                for kk, vv in v.items():
                    w.writerow([f"recall_{kk}", vv["mean"], vv["sd"], "", ""])
            else:
                w.writerow([k, v["mean"], v["sd"], v.get("min", ""), v.get("max", "")])

    print("\n===== mean +/- sd over seeds =====")
    for k in ("PR_base", "PR_fed", "delta_PR_points", "prec_base", "prec_fed",
              "delta_precision", "lat_base_ms", "lat_fed_ms", "TP_base", "FP_base",
              "TP_fed", "FP_fed", "MI_nats", "MI_all_rows_nats", "MI_null_p95",
              "PR_all_labels_base", "PR_all_labels_fed"):
        s = summary[k]
        print(f"{k:22s} {s['mean']:12.4f} +/- {s['sd']:.4f}")
    print("\nper-class recall (mean +/- sd, %):")
    for k, v in summary["per_class_recall"].items():
        print(f"  {k:18s} {v['mean']*100:8.2f} +/- {v['sd']*100:.2f}")
    above = [r["seed"] for r in records if r["MI_nats"] > r["MI_null_p95"]]
    print(f"\nseeds whose MI estimate exceeds the 95th percentile of its null: "
          f"{above}  ({len(above)} of {len(records)})")
    print(f"R = {records[0]['R']}, Cost_FL = {records[0]['Cost_FL']:,} B, "
          f"Cost_centralized = {records[0]['Cost_central']:,} B, "
          f"reduction = {records[0]['Cost_central']/records[0]['Cost_FL']:,.1f}x")


if __name__ == "__main__":
    main()
